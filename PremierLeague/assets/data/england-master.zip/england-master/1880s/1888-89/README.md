

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Preston North End             22  10  1  0  39:7     8  3  0  35:8     74:15  +59   58
 2. Aston Villa                   22  10  0  1  44:16    2  5  4  17:27    61:43  +18   41
 3. Wolverhampton Wanderers       22   8  2  1  30:14    4  2  5  20:23    50:37  +13   40
 4. Blackburn Rovers              22   7  4  0  44:22    3  2  6  22:23    66:45  +21   36
 5. Bolton Wanderers              22   6  0  5  35:30    4  2  5  28:29    63:59   +4   32
 6. West Bromwich Albion          22   6  2  3  25:24    4  0  7  15:22    40:46   -6   32
 7. Everton                       22   8  0  3  24:17    1  2  8  11:29    35:46  -11   29
 8. Accrington F.C.               22   5  3  3  26:17    1  5  5  22:31    48:48        26
 9. Burnley                       22   6  3  2  21:19    1  0 10  21:43    42:62  -20   24
10. Derby County                  22   5  1  5  22:20    2  1  8  19:41    41:61  -20   23
11. Notts County                  22   4  2  5  25:32    1  0 10  15:41    40:73  -33   17
12. Stoke City                    22   3  4  4  15:18    1  0 10  11:33    26:51  -25   16
~~~

(Source: `1-division1.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

