

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   30  10  3  2  36:16   11  2  2  37:22    73:38  +35   68
 2. Derby County                  30  10  2  3  45:22    6  2  7  25:28    70:50  +20   52
 3. Sheffield United              30   6  4  5  22:16    7  6  2  20:13    42:29  +13   49
 4. Preston North End             30   8  4  3  35:21    3  8  4  20:19    55:40  +15   45
 5. Liverpool                     30   7  6  2  25:10    5  3  7  21:28    46:38   +8   45
 6. Everton                       30   8  1  6  42:29    6  2  7  20:28    62:57   +5   45
 7. Bolton Wanderers              30   7  3  5  22:18    5  3  7  18:25    40:43   -3   42
 8. Sheffield Wednesday           30   9  4  2  29:11    1  7  7  13:26    42:37   +5   41
 9. Bury                          30   7  5  3  25:15    3  5  7  14:29    39:44   -5   40
10. Wolverhampton Wanderers       30   6  4  5  26:14    5  2  8  19:27    45:41   +4   39
11. Stoke City                    30   8  3  4  30:18    3  0 12  18:41    48:59  -11   36
12. West Bromwich Albion          30   7  2  6  18:16    3  4  8  15:40    33:56  -23   36
13. Blackburn Rovers              30   8  1  6  27:25    3  2 10   8:37    35:62  -27   36
14. Nottingham Forest             30   8  3  4  30:16    1  5  9  14:33    44:49   -5   35
15. Sunderland                    30   4  6  5  21:21    3  3  9  13:26    34:47  -13   30
16. Burnley                       30   4  5  6  25:25    2  2 11  18:36    43:61  -18   25
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Notts County                  30  12  1  2  60:18    7  3  5  32:25    92:43  +49   61
 2. Manchester United             30  11  4  0  37:10    6  1  8  19:24    56:34  +22   56
 3. Grimsby Town                  30  12  2  1  44:15    5  2  8  22:30    66:45  +21   55
 4. Birmingham City               30   8  3  4  36:23    8  2  5  33:24    69:47  +22   53
 5. Newcastle United              30  13  1  1  42:13    4  0 11  14:39    56:52   +4   52
 6. Manchester City               30  10  3  2  39:15    2  5  8  19:35    58:50   +8   44
 7. Blackpool                     30  11  3  1  39:16    2  2 11  20:40    59:56   +3   44
 8. Leicester City                30  11  2  2  44:19    2  2 11  15:37    59:56   +3   43
 9. Gainsborough Trinity          30  10  2  3  35:16    2  5  8  15:31    50:47   +3   43
10. Arsenal                       30  10  1  4  42:20    3  3  9  26:50    68:70   -2   43
11. Darwen                        30  13  0  2  54:16    1  0 14  13:45    67:61   +6   42
12. Loughborough                  30  10  0  5  37:14    2  1 12  13:50    50:64  -14   37
13. Burton Swifts                 30   8  3  4  33:18    2  2 11  13:41    46:59  -13   35
14. Walsall                       30   7  3  5  37:27    3  2 10  16:44    53:71  -18   35
15. Burton Wanderers              30   8  1  6  22:22    1  1 13   9:45    31:67  -36   29
16. Lincoln City                  30   4  2  9  17:27    1  0 14  10:58    27:85  -58   17
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

