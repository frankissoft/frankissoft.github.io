

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield Wednesday           34  14  3  0  34:10    6  4  7  14:18    48:28  +20   67
 2. Manchester City               34  10  4  3  35:19    9  2  6  36:26    71:45  +26   63
 3. Everton                       34  13  0  4  36:12    6  5  6  23:20    59:32  +27   62
 4. Newcastle United              34  12  3  2  31:13    6  3  8  27:32    58:45  +13   60
 5. Aston Villa                   34  13  1  3  41:16    4  6  7  29:32    70:48  +22   58
 6. Sunderland                    34  12  3  2  41:15    5  2 10  22:34    63:49  +14   56
 7. Sheffield United              34   9  6  2  40:21    6  2  9  22:36    62:57   +5   53
 8. Wolverhampton Wanderers       34  10  6  1  29:23    4  2 11  15:43    44:66  -22   50
 9. Nottingham Forest             34   7  3  7  29:26    4  6  7  28:31    57:57        42
10. Birmingham City               34   8  5  4  25:19    3  3 11  14:33    39:52  -13   41
11. Notts County                  34   9  3  5  27:26    3  2 12  10:35    37:61  -24   41
12. Middlesbrough                 34   9  3  5  30:17    0  9  8  16:30    46:47   -1   39
13. Blackburn Rovers              34   7  5  5  29:23    4  1 12  19:37    48:60  -12   39
14. Derby County                  34   7  3  7  41:33    2  7  8  17:27    58:60   -2   37
15. Stoke City                    34   9  2  6  45:26    1  5 11   9:31    54:57   -3   37
16. Bury                          34   6  8  3  25:20    1  7  9  15:33    40:53  -13   36
17. Liverpool                     34   7  5  5  24:20    2  3 12  25:42    49:62  -13   35
18. West Bromwich Albion          34   4  8  5  19:19    3  2 12  17:41    36:60  -24   31
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       34  15  2  0  67:5     6  5  6  24:17    91:22  +69   70
 2. Preston North End             34  13  4  0  38:10    7  6  4  24:14    62:24  +38   70
 3. Manchester United             34  14  2  1  42:14    6  6  5  23:19    65:33  +32   68
 4. Bristol City                  34  14  2  1  53:12    4  4  9  20:29    73:41  +32   60
 5. Burnley                       34  12  2  3  31:20    3  7  7  19:35    50:55   -5   54
 6. Grimsby Town                  34  12  5  0  39:12    2  3 12  11:37    50:49   +1   50
 7. Bolton Wanderers              34  10  3  4  38:11    2  7  8  21:30    59:41  +18   46
 8. Gainsborough Trinity          34  10  2  5  34:17    4  1 12  19:43    53:60   -7   45
 9. Bradford City                 34   8  5  4  30:25    4  2 11  15:34    45:59  -14   43
10. Barnsley                      34  10  5  2  25:12    1  5 11  13:45    38:57  -19   43
11. Chesterfield                  34   8  5  4  22:12    3  3 11  15:33    37:45   -8   41
12. Lincoln City                  34   9  4  4  25:18    2  4 11  16:40    41:58  -17   41
13. Burton United                 34   8  6  3  33:16    3  1 13  12:45    45:61  -16   40
14. Port Vale                     34  10  3  4  44:20    0  6 11  10:32    54:52   +2   39
15. Blackpool                     34   8  2  7  25:27    3  3 11  15:40    40:67  -27   38
16. Glossop North End             34   7  4  6  42:25    3  2 12  15:39    57:64   -7   36
17. Stockport County              34   7  7  3  28:23    1  4 12  12:49    40:72  -32   35
18. Leicester City                34   5  8  4  26:21    1  2 14  16:61    42:82  -40   28
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

