

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Newcastle United              34  14  1  2  41:12    9  1  7  31:21    72:33  +39   71
 2. Everton                       34  14  2  1  36:11    7  3  7  27:25    63:36  +27   68
 3. Manchester City               34  14  3  0  46:17    6  3  8  20:20    66:37  +29   66
 4. Aston Villa                   34  11  2  4  32:15    8  2  7  31:28    63:43  +20   61
 5. Sheffield United              34  13  0  4  39:20    6  2  9  25:36    64:56   +8   59
 6. Sunderland                    34  11  3  3  37:19    5  5  7  23:25    60:44  +16   56
 7. Birmingham City               34  11  1  5  32:17    6  4  7  22:21    54:38  +16   56
 8. Preston North End             34   9  5  3  28:13    4  5  8  14:24    42:37   +5   49
 9. Sheffield Wednesday           34  10  3  4  39:22    4  2 11  22:35    61:57   +4   47
10. Arsenal                       34   9  5  3  19:12    3  4 10  17:28    36:40   -4   45
11. Derby County                  34   9  4  4  29:19    3  4 10   8:29    37:48  -11   44
12. Stoke City                    34  10  3  4  26:18    3  1 13  14:40    40:58  -18   43
13. Blackburn Rovers              34   9  3  5  28:18    2  2 13  12:33    40:51  -11   38
14. Wolverhampton Wanderers       34  10  2  5  30:23    1  2 14  17:50    47:73  -26   37
15. Middlesbrough                 34   7  3  7  21:24    2  5 10  15:32    36:56  -20   35
16. Bury                          34   8  2  7  34:26    2  2 13  13:41    47:67  -20   34
17. Nottingham Forest             34   5  3  9  24:28    4  4  9  16:33    40:61  -21   34
18. Notts County                  34   1  7  9  16:33    4  1 12  20:36    36:69  -33   23
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     34  14  3  0  60:12   13  1  3  33:13    93:25  +68   85
 2. Bolton Wanderers              34  15  0  2  53:16   12  2  3  34:16    87:32  +55   83
 3. Manchester United             34  16  0  1  60:10    8  5  4  21:20    81:30  +51   77
 4. Bristol City                  34  12  3  2  40:12    7  1  9  26:33    66:45  +21   61
 5. Chesterfield                  34   9  6  2  26:11    5  5  7  18:24    44:35   +9   53
 6. Gainsborough Trinity          34  11  4  2  32:15    3  4 10  29:43    61:58   +3   50
 7. Barnsley                      34  11  4  2  29:13    3  1 13   9:43    38:56  -18   47
 8. Bradford City                 34   8  5  4  31:20    4  3 10  14:29    45:49   -4   44
 9. West Bromwich Albion          34   8  2  7  28:20    5  2 10  28:28    56:48   +8   43
10. Lincoln City                  34   9  4  4  31:16    3  3 11  11:24    42:40   +2   43
11. Burnley                       34  10  1  6  31:21    2  5 10  12:31    43:52   -9   42
12. Grimsby Town                  34   9  3  5  22:14    2  5 10  11:32    33:46  -13   41
13. Glossop North End             34   7  5  5  23:14    3  5  9  14:32    37:46   -9   40
14. Leicester City                34   8  3  6  30:25    3  4 10  10:30    40:55  -15   40
15. Blackpool                     34   8  5  4  26:15    1  5 11  10:33    36:48  -12   37
16. Port Vale                     34   7  4  6  28:25    3  3 11  19:47    47:72  -25   37
17. Burton United                 34   7  2  8  20:29    1  2 14  10:55    30:84  -54   28
18. Doncaster Rovers              34   3  2 12  12:32    0  0 17  11:49    23:81  -58   11
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

