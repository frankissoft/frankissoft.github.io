

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  17  3  1  50:13    9  5  7  20:18    70:31  +39   86
 2. Sunderland                    42  15  5  1  50:25    7  5  9  22:29    72:54  +18   76
 3. Huddersfield Town             42  14  2  5  35:15    7  9  5  25:17    60:32  +28   74
 4. Everton                       42  14  4  3  41:20    6  3 12  22:39    63:59   +4   67
 5. Newcastle United              42  13  6  2  31:11    5  6 10  14:26    45:37   +8   66
 6. Aston Villa                   42  15  3  3  42:11    3  7 11  22:40    64:51  +13   64
 7. West Bromwich Albion          42  12  7  2  38:10    5  4 12  20:39    58:49   +9   62
 8. Manchester City               42  14  6  1  38:16    3  5 13  12:33    50:49   +1   62
 9. Cardiff City                  42  15  2  4  51:18    3  5 13  22:41    73:59  +14   61
10. Sheffield United              42  11  7  3  41:20    5  3 13  27:44    68:64   +4   58
11. Tottenham Hotspur             42  11  3  7  34:22    6  4 11  16:28    50:50        58
12. Arsenal                       42  13  4  4  38:16    3  6 12  23:46    61:62   -1   58
13. Burnley                       42  12  3  6  39:24    4  3 14  19:35    58:59   -1   54
14. Bolton Wanderers              42  11  8  2  36:17    3  4 14  14:41    50:58   -8   54
15. Blackburn Rovers              42  12  7  2  32:19    2  5 14  15:43    47:62  -15   54
16. Preston North End             42  12  3  6  41:26    1  8 12  19:38    60:64   -4   50
17. Birmingham City               42  10  4  7  25:19    3  7 11  16:38    41:57  -16   50
18. Middlesbrough                 42  11  4  6  41:25    2  6 13  16:38    57:63   -6   49
19. Nottingham Forest             42  12  2  7  25:23    1  6 14  16:47    41:70  -29   47
20. Chelsea                       42   5 13  3  29:20    4  5 12  16:33    45:53   -8   45
21. Stoke City                    42   7  9  5  28:19    3  1 17  19:48    47:67  -20   40
22. Oldham Athletic               42   9  6  6  21:20    1  4 16  14:45    35:65  -30   40
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Notts County                  42  16  1  4  29:15    7  6  8  17:19    46:34  +12   76
 2. Leicester City                42  14  2  5  42:19    7  7  7  23:25    65:44  +21   72
 3. West Ham United               42   9  8  4  21:11   11  3  7  42:27    63:38  +25   71
 4. Blackpool                     42  12  4  5  37:14    6  7  8  23:29    60:43  +17   65
 5. Manchester United             42  10  6  5  25:17    7  8  6  26:19    51:36  +15   65
 6. Bury                          42  14  5  2  41:16    4  6 11  14:30    55:46   +9   65
 7. Leeds United                  42  11  8  2  26:10    7  3 11  17:26    43:36   +7   65
 8. Sheffield Wednesday           42  14  3  4  36:16    3  9  9  18:31    54:47   +7   63
 9. Barnsley                      42  12  4  5  42:21    5  7  9  20:30    62:51  +11   62
10. Fulham                        42  10  7  4  29:12    6  5 10  14:20    43:32  +11   60
11. Southampton                   42  10  5  6  28:21    4  9  8  12:19    40:40        56
12. Hull City                     42   9  8  4  29:22    5  6 10  14:23    43:45   -2   56
13. South Shields                 42  11  7  3  26:12    4  3 14   9:32    35:44   -9   55
14. Derby County                  42   9  5  7  25:16    5  6 10  21:34    46:50   -4   53
15. Coventry City                 42  12  2  7  35:21    3  5 13  11:42    46:63  -17   52
16. Port Vale                     42   8  6  7  23:18    6  3 12  16:33    39:51  -12   51
17. Crystal Palace                42  10  7  4  33:16    3  4 14  21:46    54:62   -8   50
18. Stockport County              42  10  6  5  32:24    4  2 15  11:34    43:58  -15   50
19. Bradford City                 42   8  7  6  27:18    4  6 11  14:27    41:45   -4   49
20. Leyton Orient                 42   9  6  6  26:17    3  6 12  14:33    40:50  -10   48
21. Rotherham County              42  10  7  4  30:19    3  2 16  14:44    44:63  -19   48
22. Wolverhampton Wanderers       42   9  4  8  32:26    0  5 16  10:51    42:77  -35   36
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Nelson                        38  15  2  2  37:10    9  1  9  24:31    61:41  +20   75
 2. Bradford Park Avenue          38  14  4  1  51:15    5  5  9  16:23    67:38  +29   66
 3. Walsall                       38  13  4  2  32:14    6  4  9  19:30    51:44   +7   65
 4. Chesterfield                  38  13  5  1  49:18    6  2 11  19:34    68:52  +16   64
 5. Wigan Borough                 38  14  3  2  45:11    4  5 10  19:28    64:39  +25   62
 6. Crewe Alexandra               38  13  3  3  32:9     4  6  9  16:29    48:38  +10   60
 7. Halifax Town                  38  11  4  4  29:14    6  3 10  24:32    53:46   +7   58
 8. Accrington Stanley            38  14  2  3  40:21    3  5 11  19:44    59:65   -6   58
 9. Darlington                    38  13  3  3  43:14    2  7 10  16:32    59:46  +13   55
10. Wrexham                       38  13  5  1  29:12    1  5 13   9:36    38:48  -10   52
11. Stalybridge Celtic            38  13  2  4  32:18    2  4 13  10:29    42:47   -5   51
12. Rochdale                      38   8  5  6  29:22    5  5  9  13:31    42:53  -11   49
13. Lincoln City                  38   9  7  3  21:11    4  3 12  18:44    39:55  -16   49
14. Grimsby Town                  38  10  3  6  35:18    4  2 13  20:34    55:52   +3   47
15. Tranmere Rovers               38  11  4  4  41:21    1  4 14   8:38    49:59  -10   44
16. Barrow                        38  11  2  6  31:17    2  2 15  19:43    50:60  -10   43
17. Southport                     38  11  3  5  21:12    1  4 14  11:34    32:46  -14   43
18. Hartlepool United             38  10  6  3  34:14    0  6 13  14:40    48:54   -6   42
19. Ashington                     38  10  3  6  34:33    1  5 13  17:44    51:77  -26   41
20. Durham City                   38   7  9  3  31:19    2  1 16  12:40    43:59  -16   37
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bristol City                  42  16  4  1  43:13    8  7  6  23:27    66:40  +26   83
 2. Plymouth Argyle               42  18  3  0  47:6     5  4 12  14:23    61:29  +32   76
 3. Swansea City                  42  13  6  2  46:14    9  3  9  32:31    78:45  +33   75
 4. Brighton & Hove Albion        42  15  3  3  39:13    5  8  8  13:21    52:34  +18   71
 5. Luton Town                    42  14  4  3  47:18    7  3 11  21:31    68:49  +19   70
 6. Portsmouth                    42  10  5  6  34:20    9  3  9  24:32    58:52   +6   65
 7. Northampton Town              42  13  6  2  40:17    4  5 12  14:27    54:44  +10   62
 8. Swindon Town                  42  14  4  3  41:17    3  7 11  21:39    62:56   +6   62
 9. Watford                       42  10  6  5  35:23    7  4 10  22:31    57:54   +3   61
10. Millwall                      42   9 10  2  27:13    5  8  8  18:27    45:40   +5   60
11. Queens Park Rangers           42  10  4  7  34:24    6  6  9  20:25    54:49   +5   58
12. Charlton Athletic             42  11  6  4  33:14    3  8 10  22:37    55:51   +4   56
13. Bristol Rovers                42   7  9  5  25:19    6  7  8  10:17    35:36   -1   55
14. Gillingham                    42  13  4  4  38:18    2  3 16  13:41    51:59   -8   52
15. Brentford                     42   9  4  8  27:23    4  8  9  14:28    41:51  -10   51
16. Southend United               42  10  6  5  35:18    2  7 12  14:36    49:54   -5   49
17. Norwich City                  42   8  7  6  29:26    5  3 13  22:45    51:71  -20   49
18. Merthyr Town                  42  10  4  7  27:17    1 10 10  12:31    39:48   -9   47
19. Exeter City                   42  10  4  7  27:18    3  3 15  20:66    47:84  -37   46
20. Reading                       42   9  8  4  24:15    1  6 14  12:40    36:55  -19   44
21. Aberdare Athletic             42   6  8  7  25:23    3  3 15  17:47    42:70  -28   38
22. Newport County                42   8  6  7  28:21    0  5 16  12:49    40:70  -30   35
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

