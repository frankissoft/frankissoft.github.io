

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Huddersfield Town             42  14  6  1  50:17    9  5  7  42:43    92:60  +32   80
 2. Arsenal                       42  16  2  3  57:19    6  6  9  30:44    87:63  +24   74
 3. Sunderland                    42  17  2  2  67:30    4  4 13  29:50    96:80  +16   69
 4. Bury                          42  12  4  5  55:34    8  3 10  30:43    85:77   +8   67
 5. Sheffield United              42  15  3  3  72:29    4  5 12  30:53   102:82  +20   65
 6. Manchester United             42  12  4  5  40:26    7  2 12  26:47    66:73   -7   63
 7. Bolton Wanderers              42  11  6  4  46:31    6  4 11  29:45    75:76   -1   61
 8. Aston Villa                   42  12  7  2  56:25    4  5 12  30:51    86:76  +10   60
 9. Newcastle United              42  13  3  5  59:33    3  7 11  25:42    84:75   +9   58
10. Liverpool                     42   9  8  4  43:27    5  8  8  27:36    70:63   +7   58
11. Blackburn Rovers              42  11  6  4  59:33    4  5 12  32:47    91:80  +11   56
12. West Bromwich Albion          42  13  5  3  59:29    3  3 15  20:49    79:78   +1   56
13. Birmingham City               42  14  2  5  35:25    2  6 13  31:56    66:81  -15   56
14. Cardiff City                  42   8  5  8  30:25    8  2 11  31:51    61:76  -15   55
15. Everton                       42   9  9  3  42:26    3  9  9  30:44    72:70   +2   54
16. Tottenham Hotspur             42  11  4  6  45:36    4  5 12  21:43    66:79  -13   54
17. Leicester City                42  11  3  7  42:32    3  7 11  28:48    70:80  -10   52
18. West Ham United               42  14  2  5  45:27    1  5 15  18:49    63:76  -13   52
19. Leeds United                  42  11  5  5  38:28    3  3 15  26:48    64:76  -12   50
20. Burnley                       42   7  7  7  43:35    6  3 12  42:73    85:108 -23   49
21. Manchester City               42   8  7  6  48:42    4  4 13  41:58    89:100 -11   47
22. Notts County                  42  11  4  6  37:26    2  3 16  17:48    54:74  -20   46
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield Wednesday           42  19  0  2  61:17    8  6  7  27:31    88:48  +40   87
 2. Derby County                  42  17  2  2  57:17    8  5  8  20:25    77:42  +35   82
 3. Chelsea                       42  10  7  4  42:22    9  7  5  34:27    76:49  +27   71
 4. Wolverhampton Wanderers       42  15  4  2  55:15    6  3 12  29:45    84:60  +24   70
 5. Swansea City                  42  13  6  2  50:16    6  5 10  27:41    77:57  +20   68
 6. Middlesbrough                 42  14  1  6  56:28    7  1 13  21:40    77:68   +9   65
 7. Port Vale                     42  15  3  3  53:18    4  3 14  26:51    79:69  +10   63
 8. Oldham Athletic               42  14  4  3  52:24    4  4 13  22:38    74:62  +12   62
 9. South Shields                 42  11  6  4  50:29    7  2 12  24:36    74:65   +9   62
10. Blackpool                     42  12  6  3  41:16    5  5 11  35:53    76:69   +7   62
11. Portsmouth                    42  12  4  5  48:27    5  6 10  31:47    79:74   +5   61
12. Preston North End             42  17  2  2  54:28    1  5 15  17:56    71:84  -13   61
13. Hull City                     42  11  4  6  40:19    5  5 11  23:42    63:61   +2   57
14. Southampton                   42  11  2  8  39:25    4  6 11  24:38    63:63        53
15. Darlington                    42   9  5  7  51:31    5  5 11  21:46    72:77   -5   52
16. Nottingham Forest             42  11  4  6  38:25    3  4 14  13:48    51:73  -22   50
17. Bradford City                 42   9  5  7  28:26    4  5 12  19:40    47:66  -19   49
18. Barnsley                      42  10  7  4  38:22    2  5 14  20:62    58:84  -26   48
19. Leyton Orient                 42   8  6  7  30:21    4  3 14  20:44    50:65  -15   45
20. Fulham                        42   8  6  7  32:29    3  6 12  14:48    46:77  -31   45
21. Stoke City                    42   8  5  8  32:23    4  3 14  22:54    54:77  -23   44
22. Stockport County              42   8  7  6  34:28    0  2 19  17:69    51:97  -46   33
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Grimsby Town                  42  20  1  0  61:8     6  8  7  30:32    91:40  +51   87
 2. Bradford Park Avenue          42  18  2  1  65:10    8  6  7  36:33   101:43  +58   86
 3. Rochdale                      42  16  1  4  55:25   11  4  6  49:33   104:58  +46   86
 4. Chesterfield                  42  18  2  1  70:19    7  3 11  30:35   100:54  +46   80
 5. Tranmere Rovers               42  15  2  4  45:27    4  4 13  28:56    73:83  -10   63
 6. Hartlepool United             42  15  5  1  59:23    3  3 15  23:50    82:73   +9   62
 7. Halifax Town                  42  12  5  4  34:19    5  6 10  19:31    53:50   +3   62
 8. Crewe Alexandra               42  14  3  4  43:23    3  6 12  20:38    63:61   +2   60
 9. Durham City                   42  14  5  2  45:19    4  1 16  18:51    63:70   -7   60
10. Nelson                        42  12  8  1  67:29    4  3 14  22:42    89:71  +18   59
11. Doncaster Rovers              42  11  7  3  52:25    5  4 12  28:47    80:72   +8   59
12. Ashington                     42  11  6  4  44:23    5  5 11  26:39    70:62   +8   59
13. New Brighton                  42  13  4  4  51:29    4  4 13  18:38    69:67   +2   59
14. Rotherham United              42  13  3  5  44:28    4  4 13  25:64    69:92  -23   58
15. Lincoln City                  42  14  2  5  42:28    3  3 15  24:54    66:82  -16   56
16. Coventry City                 42  13  6  2  47:19    3  0 18  26:63    73:82   -9   54
17. Accrington Stanley            42  14  0  7  49:34    3  3 15  32:71    81:105 -24   54
18. Wigan Borough                 42  12  5  4  53:22    1  6 14  15:52    68:74   -6   50
19. Wrexham                       42   9  6  6  39:31    2  4 15  24:61    63:92  -29   43
20. Southport                     42   9  6  6  37:34    2  4 15  25:58    62:92  -30   43
21. Walsall                       42   9  4  8  40:34    1  2 18  18:73    58:107 -49   36
22. Barrow                        42   4  2 15  28:49    3  2 16  22:49    50:98  -48   25
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Plymouth Argyle               42  16  2  3  71:33    8  6  7  36:34   107:67  +40   80
 2. Reading                       42  16  5  0  49:16    7  6  8  28:36    77:52  +25   80
 3. Millwall                      42  14  6  1  52:12    7  5  9  21:27    73:39  +34   74
 4. Bristol City                  42  14  3  4  42:15    7  6  8  30:36    72:51  +21   72
 5. Brighton & Hove Albion        42  12  4  5  47:33    7  5  9  37:40    84:73  +11   66
 6. Swindon Town                  42  16  2  3  48:22    4  4 13  21:42    69:64   +5   66
 7. Luton Town                    42  16  4  1  60:25    2  3 16  20:50    80:75   +5   61
 8. Southend United               42  13  2  6  50:20    6  2 13  28:53    78:73   +5   61
 9. Crystal Palace                42  16  1  4  50:21    3  2 16  25:58    75:79   -4   60
10. AFC Bournemouth               42  10  5  6  44:30    7  4 10  31:61    75:91  -16   60
11. Aberdare Athletic             42  11  6  4  50:24    6  2 13  24:42    74:66   +8   59
12. Gillingham                    42  11  4  6  36:19    6  4 11  17:30    53:49   +4   59
13. Northampton Town              42  13  3  5  47:26    4  4 13  35:54    82:80   +2   58
14. Norwich City                  42  11  5  5  35:26    4  4 13  23:47    58:73  -15   54
15. Watford                       42  12  5  4  47:26    3  4 14  26:63    73:89  -16   54
16. Brentford                     42  12  4  5  44:32    4  2 15  25:62    69:94  -25   54
17. Merthyr Town                  42  13  3  5  51:25    1  8 12  18:50    69:75   -6   53
18. Newport County                42  11  5  5  39:27    3  5 13  25:47    64:74  -10   52
19. Bristol Rovers                42   9  4  8  44:28    6  2 13  22:41    66:69   -3   51
20. Exeter City                   42  13  2  6  54:25    2  3 16  18:45    72:70   +2   50
21. Charlton Athletic             42   9  7  5  32:23    2  6 13  16:45    48:68  -20   46
22. Queens Park Rangers           42   5  7  9  23:32    1  2 18  14:52    37:84  -47   27
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

