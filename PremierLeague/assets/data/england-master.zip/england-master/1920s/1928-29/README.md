

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield Wednesday           42  18  3  0  55:16    3  7 11  31:46    86:62  +24   73
 2. Aston Villa                   42  16  2  3  62:30    7  2 12  36:51    98:81  +17   73
 3. Leicester City                42  16  5  0  67:22    5  4 12  29:45    96:67  +29   72
 4. Sunderland                    42  16  2  3  67:30    4  5 12  26:45    93:75  +18   67
 5. Derby County                  42  12  5  4  56:24    6  5 10  30:47    86:71  +15   64
 6. Liverpool                     42  11  4  6  53:28    6  8  7  37:36    90:64  +26   63
 7. Manchester City               42  12  3  6  63:40    6  6  9  32:46    95:86   +9   63
 8. Newcastle United              42  15  2  4  48:29    4  4 13  22:43    70:72   -2   63
 9. Blackburn Rovers              42  11  6  4  42:26    6  5 10  30:37    72:63   +9   62
10. Arsenal                       42  11  6  4  43:25    5  7  9  34:47    77:72   +5   61
11. Leeds United                  42  11  5  5  42:28    5  4 12  29:56    71:84  -13   57
12. Sheffield United              42  12  5  4  57:30    3  6 12  29:55    86:85   +1   56
13. Birmingham City               42   8  7  6  37:32    7  3 11  31:45    68:77   -9   55
14. Manchester United             42   8  8  5  32:23    6  5 10  34:53    66:76  -10   55
15. Everton                       42  11  2  8  38:31    6  2 13  25:44    63:75  -12   55
16. Bolton Wanderers              42  10  6  5  44:25    4  6 11  29:55    73:80   -7   54
17. West Ham United               42  11  6  4  55:31    4  3 14  31:65    86:96  -10   54
18. Huddersfield Town             42   9  6  6  45:23    5  5 11  25:38    70:61   +9   53
19. Burnley                       42  12  5  4  55:32    3  3 15  26:71    81:103 -22   53
20. Portsmouth                    42  13  2  6  43:26    2  4 15  13:54    56:80  -24   51
21. Bury                          42   9  5  7  38:35    3  2 16  24:64    62:99  -37   43
22. Cardiff City                  42   7  7  7  34:26    1  6 14   9:33    43:59  -16   37
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Middlesbrough                 42  14  4  3  54:22    8  7  6  38:35    92:57  +35   77
 2. Grimsby Town                  42  16  2  3  49:24    8  3 10  33:37    82:61  +21   77
 3. Bradford Park Avenue          42  18  2  1  62:22    4  2 15  26:48    88:70  +18   70
 4. Notts County                  42  13  4  4  51:24    6  5 10  27:41    78:65  +13   66
 5. Southampton                   42  12  6  3  48:22    5  8  8  26:38    74:60  +14   65
 6. West Bromwich Albion          42  13  4  4  50:25    6  4 11  30:54    80:79   +1   65
 7. Blackpool                     42  13  4  4  49:18    6  3 12  43:58    92:76  +16   64
 8. Stoke City                    42  12  7  2  46:16    5  5 11  28:35    74:51  +23   63
 9. Chelsea                       42  10  6  5  40:30    7  4 10  24:35    64:65   -1   61
10. Tottenham Hotspur             42  16  3  2  50:26    1  6 14  25:55    75:81   -6   60
11. Nottingham Forest             42   8  6  7  34:33    7  6  8  37:37    71:70   +1   57
12. Millwall                      42  10  4  7  43:35    6  3 12  28:51    71:86  -15   55
13. Barnsley                      42  12  4  5  51:28    4  2 15  18:38    69:66   +3   54
14. Preston North End             42  12  6  3  58:27    3  3 15  19:52    77:79   -2   54
15. Reading                       42  12  3  6  48:30    3  6 12  15:56    63:86  -23   54
16. Hull City                     42   8  8  5  38:24    5  6 10  20:39    58:63   -5   53
17. Oldham Athletic               42  15  2  4  37:23    1  3 17  17:51    54:74  -20   53
18. Wolverhampton Wanderers       42   9  6  6  41:31    6  1 14  36:50    77:81   -4   52
19. Swansea City                  42  12  3  6  46:26    1  7 13  16:49    62:75  -13   49
20. Bristol City                  42  11  6  4  37:25    2  4 15  21:47    58:72  -14   49
21. Port Vale                     42  14  1  6  53:25    1  3 17  18:61    71:86  -15   49
22. Leyton Orient                 42  10  4  7  29:25    2  4 15  16:47    45:72  -27   44
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bradford City                 42  17  2  2  82:18   10  7  4  46:25   128:43  +85   90
 2. Stockport County              42  19  2  0  77:23    9  4  8  34:35   111:58  +53   90
 3. Wrexham                       42  17  2  2  59:25    4  8  9  32:44    91:69  +22   73
 4. Wigan Borough                 42  16  4  1  55:16    5  5 11  27:33    82:49  +33   72
 5. Doncaster Rovers              42  14  3  4  39:20    6  7  8  37:46    76:66  +10   70
 6. Lincoln City                  42  15  3  3  58:18    6  3 12  33:49    91:67  +24   69
 7. Tranmere Rovers               42  15  3  3  55:21    7  0 14  24:56    79:77   +2   69
 8. Carlisle United               42  15  3  3  61:27    4  5 12  25:50    86:77   +9   65
 9. Crewe Alexandra               42  11  6  4  47:23    7  2 12  33:45    80:68  +12   62
10. South Shields                 42  13  5  3  57:23    5  3 13  26:50    83:73  +10   62
11. Chesterfield                  42  13  2  6  46:28    5  3 13  25:49    71:77   -6   59
12. Southport                     42  13  5  3  52:27    3  3 15  23:58    75:85  -10   56
13. Nelson                        42  14  1  6  48:28    3  4 14  29:62    77:90  -13   56
14. New Brighton                  42  11  3  7  40:28    4  6 11  24:43    64:71   -7   54
15. Rotherham United              42  12  5  4  44:23    3  4 14  16:54    60:77  -17   54
16. Halifax Town                  42  11  7  3  42:24    2  6 13  21:38    63:62   +1   52
17. Rochdale                      42  12  4  5  55:34    1  6 14  23:62    78:96  -18   49
18. Accrington Stanley            42  11  5  5  42:22    2  3 16  26:60    68:82  -14   47
19. Darlington                    42  12  6  3  47:26    1  1 19  17:62    64:88  -24   46
20. Barrow                        42   7  6  8  42:37    3  2 16  22:56    64:93  -29   38
21. Hartlepool United             42   9  4  8  35:38    1  2 18  24:74    59:112 -53   36
22. Ashington                     42   6  5 10  31:52    2  2 17  14:63    45:115 -70   31
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Charlton Athletic             42  14  5  2  51:22    9  3  9  35:38    86:60  +26   77
 2. Crystal Palace                42  14  2  5  40:25    9  6  6  41:42    81:67  +14   77
 3. Fulham                        42  14  3  4  60:31    7  7  7  38:40    98:71  +27   73
 4. Northampton Town              42  14  6  1  68:23    6  6  9  28:34    96:57  +39   72
 5. Plymouth Argyle               42  14  6  1  51:13    6  6  9  32:38    83:51  +32   72
 6. Queens Park Rangers           42  13  7  1  50:22    6  7  8  32:39    82:61  +21   71
 7. Luton Town                    42  16  3  2  64:28    3  8 10  25:45    89:73  +16   68
 8. Watford                       42  15  3  3  55:28    4  7 10  24:43    79:71   +8   67
 9. AFC Bournemouth               42  14  4  3  54:31    5  5 11  30:46    84:77   +7   66
10. Swindon Town                  42  12  5  4  48:27    3  8 10  27:45    75:72   +3   58
11. Southend United               42  10  7  4  44:27    5  4 12  36:48    80:75   +5   56
12. Coventry City                 42   9  6  6  35:23    5  8  8  27:34    62:57   +5   56
13. Brighton & Hove Albion        42  14  2  5  39:28    2  4 15  19:48    58:76  -18   54
14. Brentford                     42  11  4  6  34:21    3  6 12  22:39    56:60   -4   52
15. Walsall                       42  11  7  3  47:25    2  5 14  26:54    73:79   -6   51
16. Norwich City                  42  12  3  6  49:29    2  3 16  20:52    69:81  -12   48
17. Newport County                42   8  6  7  37:28    5  3 13  32:58    69:86  -17   48
18. Torquay United                42  10  3  8  46:36    4  3 14  20:48    66:84  -18   48
19. Bristol Rovers                42   9  6  6  39:28    4  1 16  21:51    60:79  -19   46
20. Merthyr Town                  42  11  6  4  42:28    0  2 19  13:75    55:103 -48   41
21. Gillingham                    42   7  8  6  22:24    3  1 17  21:59    43:83  -40   39
22. Exeter City                   42   7  6  8  49:40    2  5 14  18:48    67:88  -21   38
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

