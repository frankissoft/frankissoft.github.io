

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield Wednesday           42  15  4  2  56:20   11  4  6  49:37   105:57  +48   86
 2. Derby County                  42  16  4  1  61:32    5  4 12  29:50    90:82   +8   71
 3. Aston Villa                   42  13  1  7  54:33    8  4  9  38:50    92:83   +9   68
 4. Leeds United                  42  15  2  4  52:22    5  4 12  27:41    79:63  +16   66
 5. Manchester City               42  12  5  4  51:33    7  4 10  40:48    91:81  +10   66
 6. Blackburn Rovers              42  15  2  4  65:36    4  5 12  34:57    99:93   +6   64
 7. West Ham United               42  14  2  5  51:26    5  3 13  35:53    86:79   +7   62
 8. Sunderland                    42  13  3  5  50:35    5  4 12  26:45    76:80   -4   61
 9. Leicester City                42  12  5  4  57:42    5  4 12  29:48    86:90   -4   60
10. Huddersfield Town             42   9  7  5  32:21    8  2 11  31:48    63:69   -6   60
11. Birmingham City               42  13  3  5  40:21    3  6 12  27:41    67:62   +5   57
12. Liverpool                     42  11  5  5  33:29    5  4 12  30:50    63:79  -16   57
13. Portsmouth                    42  10  6  5  43:25    5  4 12  23:37    66:62   +4   55
14. Bolton Wanderers              42  11  5  5  46:24    4  4 13  28:50    74:74        54
15. Middlesbrough                 42  11  3  7  48:31    5  3 13  34:53    82:84   -2   54
16. Arsenal                       42  10  2  9  49:26    4  9  8  29:40    78:66  +12   53
17. Manchester United             42  11  4  6  39:34    4  4 13  28:54    67:88  -21   53
18. Grimsby Town                  42   8  6  7  39:39    7  1 13  34:50    73:89  -16   52
19. Newcastle United              42  13  4  4  52:32    2  3 16  19:60    71:92  -21   52
20. Sheffield United              42  12  2  7  59:39    3  4 14  32:57    91:96   -5   51
21. Burnley                       42  11  5  5  53:34    3  3 15  26:63    79:97  -18   50
22. Everton                       42   6  7  8  48:46    6  4 11  32:46    80:92  -12   47
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Blackpool                     42  17  1  3  63:22   10  3  8  35:45    98:67  +31   85
 2. Chelsea                       42  17  3  1  49:14    5  8  8  25:32    74:46  +28   77
 3. Oldham Athletic               42  14  5  2  60:21    7  6  8  30:30    90:51  +39   74
 4. Bury                          42  14  2  5  45:27    8  3 10  33:40    78:67  +11   71
 5. Bradford Park Avenue          42  14  5  2  65:28    5  7  9  26:42    91:70  +21   69
 6. West Bromwich Albion          42  16  1  4  73:31    5  4 12  32:42   105:73  +32   68
 7. Cardiff City                  42  14  4  3  41:16    4  4 13  20:43    61:59   +2   62
 8. Southampton                   42  14  6  1  46:22    3  5 13  31:54    77:76   +1   62
 9. Wolverhampton Wanderers       42  14  3  4  53:24    2  6 13  24:55    77:79   -2   57
10. Stoke City                    42  12  4  5  41:20    4  4 13  33:52    74:72   +2   56
11. Tottenham Hotspur             42  11  8  2  43:24    4  1 16  16:37    59:61   -2   54
12. Nottingham Forest             42   9  6  6  36:28    4  9  8  19:41    55:69  -14   54
13. Charlton Athletic             42  10  6  5  39:23    4  5 12  20:40    59:63   -4   53
14. Swansea City                  42  11  5  5  42:23    3  4 14  15:38    57:61   -4   51
15. Millwall                      42  10  7  4  36:26    2  8 11  21:47    57:73  -16   51
16. Preston North End             42   7  7  7  42:36    6  4 11  23:44    65:80  -15   50
17. Barnsley                      42  12  7  2  39:22    2  1 18  17:49    56:71  -15   50
18. Hull City                     42  11  3  7  30:24    3  4 14  21:54    51:78  -27   49
19. Bradford City                 42   7  7  7  33:30    5  5 11  27:47    60:77  -17   48
20. Bristol City                  42  11  4  6  36:30    2  5 14  25:53    61:83  -22   48
21. Reading                       42  10  7  4  31:20    2  4 15  23:47    54:67  -13   47
22. Notts County                  42   8  7  6  33:26    1  8 12  21:44    54:70  -16   42
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Port Vale                     42  17  2  2  64:17   13  5  3  39:19   103:36  +67   97
 2. Stockport County              42  15  3  3  67:20   13  4  4  39:24   106:44  +62   91
 3. Darlington                    42  14  2  5  71:29    8  4  9  37:44   108:73  +35   72
 4. Chesterfield                  42  18  1  2  53:15    4  5 12  23:41    76:56  +20   72
 5. Lincoln City                  42  12  8  1  54:23    5  6 10  29:38    83:61  +22   65
 6. South Shields                 42  11  6  4  49:32    7  4 10  28:42    77:74   +3   64
 7. Hartlepool United             42  13  4  4  50:24    4  7 10  30:50    80:74   +6   62
 8. York City                     42  11  7  3  43:20    4  9  8  34:44    77:64  +13   61
 9. Rochdale                      42  14  3  4  57:30    4  4 13  32:61    89:91   -2   61
10. Crewe Alexandra               42  12  5  4  55:28    5  3 13  27:43    82:71  +11   59
11. Southport                     42  11  5  5  49:31    4  8  9  32:43    81:74   +7   58
12. Tranmere Rovers               42  12  4  5  57:35    4  5 12  26:51    83:86   -3   57
13. New Brighton                  42  13  4  4  48:22    3  4 14  20:57    68:79  -11   56
14. Carlisle United               42  13  4  4  63:33    3  3 15  27:67    90:100 -10   55
15. Doncaster Rovers              42  13  5  3  39:22    2  4 15  23:47    62:69   -7   54
16. Accrington Stanley            42  11  4  6  55:30    3  5 13  29:51    84:81   +3   51
17. Wrexham                       42  10  5  6  42:28    3  3 15  25:60    67:88  -21   47
18. Wigan Borough                 42  12  4  5  44:26    1  3 17  16:62    60:88  -28   46
19. Nelson                        42   9  4  8  31:25    4  3 14  20:55    51:80  -29   46
20. Rotherham United              42   9  4  8  46:40    2  4 15  21:73    67:113 -46   41
21. Halifax Town                  42   7  7  7  27:26    3  1 17  17:53    44:79  -35   38
22. Barrow                        42   9  4  8  31:28    2  1 18  10:70    41:98  -57   38
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Plymouth Argyle               42  18  3  0  63:12   12  5  4  35:26    98:38  +60   98
 2. Brentford                     42  21  0  0  66:12    7  5  9  28:32    94:44  +50   89
 3. Queens Park Rangers           42  13  5  3  46:26    8  4  9  34:42    80:68  +12   72
 4. Brighton & Hove Albion        42  16  2  3  54:20    5  6 10  33:43    87:63  +24   71
 5. Northampton Town              42  14  6  1  53:20    7  2 12  29:38    82:58  +24   71
 6. Coventry City                 42  14  3  4  54:25    5  6 10  34:48    88:73  +15   66
 7. Fulham                        42  12  7  2  54:32    6  5 10  33:50    87:82   +5   66
 8. Norwich City                  42  14  4  3  55:28    4  6 11  33:49    88:77  +11   64
 9. Crystal Palace                42  14  5  2  56:26    2  8 11  24:48    80:74   +6   61
10. AFC Bournemouth               42  11  6  4  47:24    4  7 10  25:37    72:61  +11   58
11. Southend United               42  11  6  4  41:19    4  7 10  28:40    69:59  +10   58
12. Leyton Orient                 42  10  8  3  38:21    4  5 12  17:41    55:62   -7   55
13. Luton Town                    42  13  4  4  42:25    1  8 12  22:53    64:78  -14   54
14. Watford                       42  10  4  7  37:30    5  4 12  23:43    60:73  -13   53
15. Swindon Town                  42  10  7  4  42:25    3  5 13  31:58    73:83  -10   51
16. Exeter City                   42  10  6  5  45:29    2  5 14  22:44    67:73   -6   47
17. Walsall                       42  10  4  7  45:24    3  4 14  26:54    71:78   -7   47
18. Newport County                42   9  9  3  48:29    3  1 17  26:56    74:85  -11   46
19. Bristol Rovers                42  11  3  7  45:31    0  5 16  22:62    67:93  -26   41
20. Gillingham                    42   9  5  7  38:28    2  3 16  13:52    51:80  -29   41
21. Torquay United                42   9  6  6  50:38    1  5 15  14:56    64:94  -30   41
22. Merthyr Town                  42   5  6 10  39:49    1  3 17  21:86    60:135 -75   27
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

