

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       42  15  4  2  45:19   10  5  6  30:28    75:47  +28   84
 2. Huddersfield Town             42  16  3  2  53:19    7  7  7  37:42    90:61  +29   79
 3. Tottenham Hotspur             42  14  3  4  51:24    7  4 10  28:32    79:56  +23   70
 4. Derby County                  42  11  8  2  45:22    6  3 12  23:32    68:54  +14   62
 5. Manchester City               42  14  4  3  50:29    3  7 11  15:43    65:72   -7   62
 6. West Bromwich Albion          42  12  4  5  49:28    5  6 10  29:42    78:70   +8   61
 7. Blackburn Rovers              42  16  5  0  57:21    2  2 17  17:60    74:81   -7   61
 8. Sunderland                    42  14  6  1  57:17    2  6 13  24:39    81:56  +25   60
 9. Leeds United                  42  13  5  3  52:21    4  3 14  23:45    75:66   +9   59
10. Portsmouth                    42  11  5  5  31:21    4  7 10  21:34    52:55   -3   57
11. Sheffield Wednesday           42   9  5  7  33:24    7  4 10  29:43    62:67   -5   57
12. Stoke City                    42  11  5  5  33:19    4  6 11  25:52    58:71  -13   56
13. Middlesbrough                 42  13  3  5  51:27    3  4 14  17:53    68:80  -12   55
14. Aston Villa                   42  10  5  6  45:34    4  7 10  33:41    78:75   +3   54
15. Wolverhampton Wanderers       42  13  4  4  50:28    1  8 12  24:58    74:86  -12   54
16. Leicester City                42  10  6  5  36:26    4  5 12  23:48    59:74  -15   53
17. Everton                       42   9  7  5  38:27    3  9  9  24:36    62:63   -1   52
18. Liverpool                     42  10  6  5  52:37    4  4 13  27:50    79:87   -8   52
19. Chelsea                       42  12  3  6  44:24    2  5 14  23:45    67:69   -2   50
20. Birmingham City               42   8  6  7  29:20    4  6 11  25:36    54:56   -2   48
21. Newcastle United              42   6 11  4  42:29    4  3 14  26:48    68:77   -9   44
22. Sheffield United              42  11  5  5  40:25    1  2 18  18:76    58:101 -43   43
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Grimsby Town                  42  15  3  3  62:28   12  2  7  41:31   103:59  +44   86
 2. Preston North End             42  15  3  3  47:20    8  3 10  24:32    71:52  +19   75
 3. Brentford                     42  15  2  4  52:24    7  5  9  33:36    85:60  +25   73
 4. Bolton Wanderers              42  14  2  5  45:22    7  7  7  34:33    79:55  +24   72
 5. Bradford Park Avenue          42  16  2  3  63:27    7  1 13  23:40    86:67  +19   72
 6. Bradford City                 42  14  4  3  46:25    6  2 13  27:42    73:67   +6   66
 7. Port Vale                     42  14  4  3  39:14    5  3 13  21:41    60:55   +5   64
 8. West Ham United               42  13  3  5  51:28    4  8  9  27:42    78:70   +8   62
 9. Oldham Athletic               42  12  5  4  48:28    5  5 11  24:32    72:60  +12   61
10. Bury                          42  12  4  5  43:31    5  5 11  27:42    70:73   -3   60
11. Burnley                       42  14  2  5  40:29    4  4 13  20:43    60:72  -12   60
12. Plymouth Argyle               42  12  7  2  43:20    3  6 12  26:50    69:70   -1   58
13. Blackpool                     42  10  8  3  39:27    5  5 11  23:37    62:64   -2   58
14. Southampton                   42  15  2  4  40:21    0  6 15  14:37    54:58   -4   53
15. Fulham                        42  13  3  5  29:17    2  4 15  19:50    48:67  -19   52
16. Hull City                     42  11  4  6  33:20    2  8 11  19:48    52:68  -16   51
17. Nottingham Forest             42  11  4  6  50:27    2  5 14  23:47    73:74   -1   48
18. Manchester United             42   9  3  9  29:33    5  3 13  30:52    59:85  -26   48
19. Notts County                  42   9  7  5  32:22    3  4 14  21:40    53:62   -9   47
20. Swansea City                  42  10  9  2  36:19    0  6 15  15:41    51:60   -9   45
21. Millwall                      42   8  8  5  21:17    3  3 15  18:51    39:68  -29   44
22. Lincoln City                  42   7  7  7  31:23    2  1 18  13:52    44:75  -31   35
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Barnsley                      42  18  3  0  64:18    9  5  7  54:43   118:61  +57   89
 2. Chesterfield                  42  18  1  2  56:17    9  6  6  30:26    86:43  +43   88
 3. Stockport County              42  18  3  0  84:23    6  8  7  31:29   115:52  +63   83
 4. Walsall                       42  18  2  1  66:18    5  5 11  31:42    97:60  +37   76
 5. Doncaster Rovers              42  17  1  3  58:24    5  8  8  25:37    83:61  +22   75
 6. Wrexham                       42  14  1  6  68:35    9  4  8  34:38   102:73  +29   74
 7. Tranmere Rovers               42  16  2  3  57:21    4  5 12  27:42    84:63  +21   67
 8. Barrow                        42  12  5  4  78:45    7  4 10  38:49   116:94  +22   66
 9. Halifax Town                  42  15  2  4  57:30    5  2 14  23:61    80:91  -11   64
10. Chester                       42  11  6  4  59:26    6  0 15  30:60    89:86   +3   57
11. Hartlepool United             42  14  3  4  54:24    2  4 15  35:69    89:93   -4   55
12. York City                     42  11  5  5  44:28    4  3 14  27:46    71:74   -3   53
13. Carlisle United               42  11  6  4  43:23    4  2 15  23:58    66:81  -15   53
14. Crewe Alexandra               42  12  3  6  54:38    3  3 15  27:59    81:97  -16   51
15. New Brighton                  42  13  3  5  41:25    1  5 15  21:62    62:87  -25   50
16. Darlington                    42  11  4  6  47:35    2  5 14  23:66    70:101 -31   48
17. Accrington Stanley            42  10  6  5  44:38    3  1 17  21:63    65:101 -36   46
18. Mansfield Town                42   9  7  5  49:29    2  5 14  32:59    81:88   -7   45
19. Gateshead                     42  10  3  8  46:40    2  6 13  30:70    76:110 -34   45
20. Southport                     42   6 11  4  35:29    2  6 13  28:61    63:90  -27   41
21. Rotherham United              42   5  7  9  31:35    5  1 15  22:56    53:91  -38   38
22. Rochdale                      42   7  5  9  34:30    2  1 18  19:73    53:103 -50   33
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Norwich City                  42  16  4  1  55:19    9  7  5  33:30    88:49  +39   86
 2. Queens Park Rangers           42  17  2  2  42:12    7  4 10  28:39    70:51  +19   78
 3. Coventry City                 42  16  3  2  70:22    5  9  7  30:32   100:54  +46   75
 4. Reading                       42  17  4  0  60:13    4  8  9  22:37    82:50  +32   75
 5. Charlton Athletic             42  14  5  2  53:27    8  3 10  30:29    83:56  +27   74
 6. Luton Town                    42  14  3  4  55:28    7  7  7  28:33    83:61  +22   73
 7. Bristol Rovers                42  14  4  3  49:21    6  7  8  28:26    77:47  +30   71
 8. Swindon Town                  42  13  5  3  42:25    4  6 11  22:43    64:68   -4   62
 9. Exeter City                   42  12  5  4  43:19    4  6 11  25:38    68:57  +11   59
10. Brighton & Hove Albion        42  12  7  2  47:18    3  6 12  21:42    68:60   +8   58
11. Leyton Orient                 42  14  4  3  60:25    2  6 13  15:44    75:69   +6   58
12. Crystal Palace                42  11  6  4  40:25    5  3 13  31:42    71:67   +4   57
13. Northampton Town              42  10  6  5  45:32    4  6 11  26:46    71:78   -7   54
14. Watford                       42  12  4  5  43:16    3  3 15  28:47    71:63   +8   52
15. Aldershot                     42   8  6  7  28:27    5  6 10  24:44    52:71  -19   51
16. Southend United               42   9  6  6  32:27    3  4 14  19:47    51:74  -23   46
17. Torquay United                42  10  4  7  32:28    3  3 15  21:65    53:93  -40   46
18. Gillingham                    42   8  8  5  49:41    3  3 15  26:55    75:96  -21   44
19. Bristol City                  42   7  8  6  33:22    3  5 13  25:63    58:85  -27   43
20. Newport County                42   6  9  6  25:23    2  8 11  24:47    49:70  -21   41
21. AFC Bournemouth               42   7  7  7  41:37    2  2 17  19:65    60:102 -42   36
22. Cardiff City                  42   6  4 11  32:43    3  2 16  25:62    57:105 -48   33
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

