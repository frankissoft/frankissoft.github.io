

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       42  15  4  2  74:17    8  8  5  41:29   115:46  +69   81
 2. Sunderland                    42  13  4  4  57:24    6 12  3  33:27    90:51  +39   73
 3. Manchester City               42  13  5  3  53:25    7  3 11  29:42    82:67  +15   68
 4. Sheffield Wednesday           42  14  7  0  42:17    4  6 11  28:47    70:64   +6   67
 5. Liverpool                     42  13  4  4  53:29    6  3 12  32:59    85:88   -3   64
 6. Derby County                  42  10  4  7  44:28    8  5  8  37:38    81:66  +15   63
 7. Grimsby Town                  42  13  6  2  49:25    4  5 12  29:35    78:60  +18   62
 8. West Bromwich Albion          42  10  8  3  55:33    7  2 12  28:50    83:83        61
 9. Everton                       42  14  5  2  64:32    2  7 12  25:56    89:88   +1   60
10. Stoke City                    42  12  5  4  46:20    6  1 14  25:50    71:70   +1   60
11. Preston North End             42  11  5  5  33:22    4  7 10  29:45    62:67   -5   57
12. Chelsea                       42  11  5  5  49:32    5  4 12  24:50    73:82   -9   57
13. Portsmouth                    42  10  5  6  41:24    5  5 11  30:48    71:72   -1   55
14. Aston Villa                   42  11  6  4  50:36    3  7 11  24:52    74:88  -14   55
15. Wolverhampton Wanderers       42  13  3  5  65:38    2  5 14  23:56    88:94   -6   53
16. Blackburn Rovers              42  12  5  4  42:23    2  6 13  24:55    66:78  -12   53
17. Huddersfield Town             42  11  5  5  52:27    3  5 13  24:44    76:71   +5   52
18. Leeds United                  42  10  6  5  48:35    3  6 12  27:57    75:92  -17   51
19. Birmingham City               42  10  3  8  36:36    3  7 11  27:45    63:81  -18   49
20. Leicester City                42   9  4  8  39:30    3  5 13  22:56    61:86  -25   45
21. Middlesbrough                 42   8  9  4  38:29    2  5 14  32:61    70:90  -20   44
22. Tottenham Hotspur             42   8  8  5  34:31    2  2 17  20:62    54:93  -39   40
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Brentford                     42  19  2  0  59:14    7  7  7  34:34    93:48  +45   87
 2. Bolton Wanderers              42  17  1  3  63:15    9  3  9  33:33    96:48  +48   82
 3. West Ham United               42  18  1  2  46:17    8  3 10  34:46    80:63  +17   82
 4. Blackpool                     42  16  4  1  46:18    5  7  9  33:39    79:57  +22   74
 5. Manchester United             42  16  2  3  50:21    7  2 12  26:34    76:55  +21   73
 6. Newcastle United              42  14  2  5  55:25    8  2 11  34:43    89:68  +21   70
 7. Plymouth Argyle               42  13  3  5  48:26    6  5 10  27:38    75:64  +11   65
 8. Fulham                        42  15  3  3  62:26    2  9 10  14:30    76:56  +20   63
 9. Bury                          42  14  1  6  38:26    5  3 13  24:47    62:73  -11   61
10. Nottingham Forest             42  12  5  4  46:23    5  3 13  30:47    76:70   +6   59
11. Sheffield United              42  11  4  6  51:30    5  5 11  28:40    79:70   +9   57
12. Burnley                       42  11  2  8  43:32    5  7  9  20:41    63:73  -10   57
13. Hull City                     42   9  6  6  32:22    7  2 12  31:52    63:74  -11   56
14. Norwich City                  42  11  6  4  51:23    3  5 13  20:38    71:61  +10   53
15. Barnsley                      42   8 10  3  32:22    5  2 14  28:61    60:83  -23   51
16. Swansea City                  42  13  5  3  41:22    1  3 17  15:45    56:67  -11   50
17. Bradford Park Avenue          42   7  8  6  32:28    4  8  9  23:35    55:63   -8   49
18. Port Vale                     42  10  7  4  42:28    1  5 15  13:46    55:74  -19   45
19. Southampton                   42   9  8  4  28:19    2  4 15  18:56    46:75  -29   45
20. Bradford City                 42  10  7  4  34:20    2  1 18  16:48    50:68  -18   44
21. Oldham Athletic               42  10  3  8  44:40    0  3 18  12:55    56:95  -39   36
22. Notts County                  42   8  3 10  29:33    1  4 16  17:64    46:97  -51   34
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Doncaster Rovers              42  16  0  5  53:21   10  5  6  34:23    87:44  +43   83
 2. Halifax Town                  42  17  2  2  50:24    8  3 10  26:43    76:67   +9   80
 3. Chester                       42  14  4  3  62:27    6 10  5  29:31    91:58  +33   74
 4. Lincoln City                  42  14  3  4  55:21    8  4  9  32:37    87:58  +29   73
 5. Darlington                    42  15  5  1  50:15    6  4 11  30:44    80:59  +21   72
 6. Tranmere Rovers               42  15  4  2  53:20    5  7  9  21:35    74:55  +19   71
 7. Stockport County              42  15  2  4  57:22    7  1 13  33:50    90:72  +18   69
 8. Mansfield Town                42  16  3  2  55:25    3  6 12  20:37    75:62  +13   66
 9. Rotherham United              42  14  4  3  56:21    5  3 13  30:52    86:73  +13   64
10. Chesterfield                  42  13  4  4  46:21    4  6 11  25:31    71:52  +19   61
11. Wrexham                       42  12  5  4  47:25    4  6 11  29:44    76:69   +7   59
12. Hartlepool United             42  12  4  5  52:34    5  3 13  28:44    80:78   +2   58
13. Crewe Alexandra               42  12  6  3  41:25    2  5 14  25:61    66:86  -20   53
14. York City                     42  12  5  4  50:20    3  1 17  26:62    76:82   -6   51
15. New Brighton                  42   9  6  6  32:25    5  2 14  27:51    59:76  -17   50
16. Walsall                       42  11  7  3  51:18    2  3 16  30:54    81:72   +9   49
17. Barrow                        42  11  5  5  37:31    2  4 15  21:56    58:87  -29   48
18. Gateshead                     42  12  4  5  36:28    1  4 16  22:68    58:96  -38   47
19. Accrington Stanley            42  11  5  5  44:36    1  5 15  19:53    63:89  -26   46
20. Rochdale                      42   9  5  7  39:35    2  6 13  14:36    53:71  -18   44
21. Southport                     42   6  6  9  27:36    4  6 11  28:49    55:85  -30   42
22. Carlisle United               42   7  6  8  34:36    1  1 19  17:66    51:102 -51   31
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Charlton Athletic             42  17  2  2  62:20   10  5  6  41:32   103:52  +51   88
 2. Reading                       42  16  5  0  59:23    5  6 10  30:42    89:65  +24   74
 3. Coventry City                 42  14  5  2  56:14    7  4 10  30:36    86:50  +36   72
 4. Luton Town                    42  12  7  2  60:23    7  5  9  32:37    92:60  +32   69
 5. Crystal Palace                42  15  3  3  51:14    4  7 10  35:50    86:64  +22   67
 6. Watford                       42  14  2  5  53:19    5  7  9  23:30    76:49  +27   66
 7. Northampton Town              42  14  4  3  40:21    5  4 12  25:46    65:67   -2   65
 8. Bristol Rovers                42  14  6  1  54:27    3  4 14  19:50    73:77   -4   61
 9. Brighton & Hove Albion        42  15  4  2  51:16    2  5 14  18:46    69:62   +7   60
10. Torquay United                42  15  2  4  60:22    3  4 14  21:53    81:75   +6   60
11. Millwall                      42  11  4  6  33:26    6  3 12  24:36    57:62   -5   58
12. Exeter City                   42  11  5  5  48:29    5  4 12  22:46    70:75   -5   57
13. Queens Park Rangers           42  14  6  1  49:22    2  3 16  14:50    63:72   -9   57
14. Leyton Orient                 42  13  3  5  47:21    2  7 12  18:44    65:65        55
15. Bristol City                  42  14  3  4  37:18    1  6 14  15:50    52:68  -16   54
16. AFC Bournemouth               42  10  5  6  36:26    5  2 14  18:45    54:71  -17   52
17. Swindon Town                  42  11  7  3  45:22    2  5 14  22:56    67:78  -11   51
18. Aldershot                     42  12  6  3  35:20    1  4 16  15:55    50:75  -25   49
19. Cardiff City                  42  11  6  4  42:27    2  3 16  20:55    62:82  -20   48
20. Gillingham                    42  10  7  4  36:25    1  6 14  19:50    55:75  -20   46
21. Southend United               42  10  4  7  40:29    1  5 15  25:49    65:78  -13   42
22. Newport County                42   7  4 10  36:40    3  1 17  18:72    54:112 -58   35
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

