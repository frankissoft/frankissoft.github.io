

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       42  17  3  1  60:18   10  2  9  28:34    88:52  +36   86
 2. Wolverhampton Wanderers       42  14  6  1  55:12    8  5  8  33:27    88:39  +49   77
 3. Charlton Athletic             42  16  3  2  49:24    6  3 12  26:35    75:59  +16   72
 4. Middlesbrough                 42  13  6  2  64:27    7  3 11  29:47    93:74  +19   69
 5. Arsenal                       42  14  3  4  34:14    5  6 10  21:27    55:41  +14   66
 6. Derby County                  42  12  3  6  39:22    7  5  9  27:33    66:55  +11   65
 7. Stoke City                    42  13  6  2  50:25    4  6 11  21:43    71:68   +3   63
 8. Bolton Wanderers              42  10  6  5  39:25    5  9  7  28:33    67:58   +9   60
 9. Preston North End             42  13  7  1  44:19    3  5 13  19:40    63:59   +4   60
10. Grimsby Town                  42  11  6  4  38:26    5  5 11  23:43    61:69   -8   59
11. Aston Villa                   42  11  3  7  44:25    5  6 10  27:35    71:60  +11   57
12. Leeds United                  42  11  5  5  40:27    5  4 12  19:40    59:67   -8   57
13. Liverpool                     42  12  6  3  40:24    2  8 11  22:39    62:63   -1   56
14. Sunderland                    42   7  7  7  30:29    6  5 10  24:38    54:67  -13   51
15. Blackpool                     42   9  8  4  37:26    3  6 12  19:42    56:68  -12   50
16. Brentford                     42  11  2  8  30:27    3  6 12  23:47    53:74  -21   50
17. Manchester United             42   7  9  5  30:20    4  7 10  27:45    57:65   -8   49
18. Portsmouth                    42  10  7  4  25:15    2  6 13  22:55    47:70  -23   49
19. Huddersfield Town             42  11  4  6  38:18    1  7 13  20:46    58:64   -6   47
20. Chelsea                       42  10  5  6  43:29    2  4 15  21:51    64:80  -16   45
21. Birmingham City               42  10  5  6  40:27    2  3 16  22:57    62:84  -22   44
22. Leicester City                42   7  6  8  35:35    2  5 14  13:47    48:82  -34   38
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Blackburn Rovers              42  17  1  3  59:23    8  4  9  35:37    94:60  +34   80
 2. Sheffield Wednesday           42  14  4  3  47:18    7  7  7  41:41    88:59  +29   74
 3. Sheffield United              42   9  9  3  35:15   11  5  5  34:26    69:41  +28   74
 4. Coventry City                 42  13  4  4  35:13    8  4  9  27:32    62:45  +17   71
 5. Luton Town                    42  13  4  4  47:27    9  1 11  35:39    82:66  +16   71
 6. Manchester City               42  13  3  5  56:35    8  4  9  40:37    96:72  +24   70
 7. Chesterfield                  42  16  1  4  54:20    4  8  9  15:32    69:52  +17   69
 8. Tottenham Hotspur             42  13  6  2  48:27    6  3 12  19:35    67:62   +5   66
 9. Newcastle United              42  13  3  5  44:21    5  7  9  17:27    61:48  +13   64
10. West Bromwich Albion          42  15  3  3  54:22    3  6 12  35:50    89:72  +17   63
11. West Ham United               42  10  5  6  36:21    7  5  9  34:31    70:52  +18   61
12. Fulham                        42  12  5  4  35:20    5  5 11  26:35    61:55   +6   61
13. Millwall                      42  12  6  3  44:18    2  8 11  20:35    64:53  +11   56
14. Burnley                       42  13  3  5  32:20    2  6 13  18:36    50:56   -6   54
15. Plymouth Argyle               42   9  7  5  24:13    6  1 14  25:42    49:55   -6   53
16. Bury                          42   9  5  7  48:36    3  8 10  17:38    65:74   -9   49
17. Southampton                   42   9  6  6  35:34    4  3 14  21:48    56:82  -26   48
18. Bradford Park Avenue          42   8  6  7  33:35    4  5 12  28:47    61:82  -21   47
19. Swansea City                  42   8  6  7  33:30    3  6 12  17:53    50:83  -33   45
20. Norwich City                  42  10  5  6  39:29    3  0 18  11:62    50:91  -41   44
21. Nottingham Forest             42   8  6  7  33:29    2  5 14  16:53    49:82  -33   41
22. Tranmere Rovers               42   6  4 11  26:38    0  1 20  13:61    39:99  -60   23
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Barnsley                      42  18  2  1  60:12   12  5  4  34:22    94:34  +60   97
 2. Doncaster Rovers              42  12  5  4  47:21    9  9  3  40:26    87:47  +40   77
 3. Bradford City                 42  16  2  3  59:21    6  6  9  30:35    89:56  +33   74
 4. Oldham Athletic               42  16  1  4  51:21    6  4 11  25:38    76:59  +17   71
 5. Southport                     42  14  5  2  47:16    6  5 10  28:38    75:54  +21   70
 6. Chester                       42  12  5  4  54:31    8  4  9  34:39    88:70  +18   69
 7. Hull City                     42  13  5  3  57:25    5  5 11  26:49    83:74   +9   64
 8. Crewe Alexandra               42  12  5  4  54:23    7  1 13  28:47    82:70  +12   63
 9. Stockport County              42  13  6  2  57:24    4  3 14  34:53    91:77  +14   60
10. Rotherham United              42  12  4  5  45:21    5  4 12  19:43    64:64        59
11. Wrexham                       42  15  2  4  46:28    2  5 14  20:51    66:79  -13   58
12. Barrow                        42  11  5  5  46:22    5  4 12  20:43    66:65   +1   57
13. Gateshead                     42  11  6  4  45:24    3  8 10  29:43    74:67   +7   56
14. Halifax Town                  42   9 10  2  33:22    4  6 11  19:32    52:54   -2   55
15. Rochdale                      42  10  5  6  58:29    5  4 12  34:53    92:82  +10   54
16. New Brighton                  42  11  2  8  46:32    4  7 10  22:41    68:73   -5   54
17. Darlington                    42  12  2  7  43:30    1  5 15  19:62    62:92  -30   46
18. Carlisle United               42  10  5  6  44:33    3  2 16  22:78    66:111 -45   46
19. Lincoln City                  42   9  6  6  40:33    3  3 15  26:59    66:92  -26   45
20. York City                     42   8  5  8  37:34    4  3 14  27:58    64:92  -28   44
21. Hartlepool United             42  10  4  7  36:33    2  3 16  19:61    55:94  -39   43
22. Accrington Stanley            42   6  5 10  30:39    1  1 19  19:64    49:103 -54   27
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Newport County                42  15  4  2  37:16    7  7  7  21:29    58:45  +13   77
 2. Crystal Palace                42  15  4  2  49:18    5  8  8  22:34    71:52  +19   72
 3. Brighton & Hove Albion        42  14  5  2  43:14    5  6 10  25:35    68:49  +19   68
 4. Watford                       42  14  6  1  44:15    3  6 12  18:36    62:51  +11   63
 5. Reading                       42  12  6  3  46:23    4  8  9  23:36    69:59  +10   62
 6. Swindon Town                  42  15  4  2  53:25    3  4 14  19:52    72:77   -5   62
 7. Ipswich Town                  42  14  3  4  46:21    2  9 10  16:31    62:52  +10   60
 8. Notts County                  42  12  6  3  36:16    5  3 13  23:38    59:54   +5   60
 9. Bristol City                  42  14  5  2  42:19    2  7 12  19:44    61:63   -2   60
10. Aldershot                     42  13  6  2  31:15    3  6 12  22:51    53:66  -13   60
11. Queens Park Rangers           42  10  8  3  44:15    5  6 10  24:34    68:49  +19   59
12. Southend United               42  14  5  2  38:13    2  4 15  23:51    61:64   -3   57
13. Cardiff City                  42  12  1  8  40:28    3 10  8  21:37    61:65   -4   56
14. Northampton Town              42  13  5  3  41:20    2  3 16  10:38    51:58   -7   53
15. Exeter City                   42   9  9  3  40:32    4  5 12  25:50    65:82  -17   53
16. AFC Bournemouth               42  10  8  3  38:22    3  5 13  14:36    52:58   -6   52
17. Port Vale                     42  10  5  6  36:23    4  4 13  16:35    52:58   -6   51
18. Torquay United                42   7  5  9  27:28    7  4 10  27:42    54:70  -16   51
19. Mansfield Town                42  10  8  3  33:19    2  7 12  11:43    44:62  -18   51
20. Leyton Orient                 42  10  9  2  40:16    1  4 16  13:39    53:55   -2   46
21. Walsall                       42   9  6  6  47:23    2  5 14  21:46    68:69   -1   44
22. Bristol Rovers                42   8  8  5  30:17    2  5 14  25:44    55:61   -6   43
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

