

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Blackpool                      3   2  0  0   4:2     1  0  0   1:0      5:2    +3    9
 2. Arsenal                        3   2  0  0   6:2     0  1  0   2:2      8:4    +4    7
 3. Sheffield United               3   1  0  0   2:1     1  1  0   1:0      3:1    +2    7
 4. Liverpool                      3   2  0  0   5:1     0  0  1   1:2      6:3    +3    6
 5. Bolton Wanderers               3   1  0  0   2:1     1  0  1   4:4      6:5    +1    6
 6. Derby County                   3   2  0  0   3:0     0  0  1   0:3      3:3          6
 7. Charlton Athletic              3   1  0  0   2:0     1  0  1   1:4      3:4    -1    6
 8. Everton                        3   0  1  0   1:1     1  1  0   4:3      5:4    +1    5
 9. Stoke City                     3   1  0  1   5:2     0  1  0   2:2      7:4    +3    4
10. Manchester United              3   1  0  0   4:0     0  1  1   1:3      5:3    +2    4
11. Chelsea                        3   1  1  0   4:3     0  0  1   0:1      4:4          4
12. Brentford                      3   1  0  0   1:0     0  1  1   2:3      3:3          4
13. Grimsby Town                   3   1  1  0   2:0     0  0  1   0:4      2:4    -2    4
14. Aston Villa                    3   1  0  1   3:2     0  0  1   0:1      3:3          3
15. Sunderland                     3   1  0  1   4:2     0  0  1   2:5      6:7    -1    3
16. Huddersfield Town              3   0  0  1   0:1     1  0  1   2:2      2:3    -1    3
17. Portsmouth                     3   1  0  0   2:1     0  0  2   1:4      3:5    -2    3
18. Wolverhampton Wanderers        3   0  1  0   2:2     0  1  1   1:2      3:4    -1    2
19. Preston North End              3   0  2  0   0:0     0  0  1   0:2      0:2    -2    2
20. Blackburn Rovers               3   0  1  0   2:2     0  0  2   1:3      3:5    -2    1
21. Leeds United                   3   0  0  2   0:2     0  1  0   0:0      0:2    -2    1
22. Middlesbrough                  3   0  1  0   2:2     0  0  2   1:6      3:8    -5    1
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Luton Town                     3   1  0  0   3:0     1  1  0   4:1      7:1    +6    7
 2. Birmingham City                3   2  0  0   4:0     0  1  0   1:1      5:1    +4    7
 3. Leicester City                 3   1  0  0   4:3     1  0  1   2:2      6:5    +1    6
 4. West Ham United                3   1  0  1   2:3     1  0  0   3:1      5:4    +1    6
 5. Plymouth Argyle                3   0  0  1   1:3     2  0  0   3:0      4:3    +1    6
 6. Nottingham Forest              3   2  0  0   4:1     0  0  1   1:4      5:5          6
 7. Coventry City                  3   1  1  0   7:5     0  1  0   1:1      8:6    +2    5
 8. Tottenham Hotspur              3   0  1  0   1:1     1  1  0   5:4      6:5    +1    5
 9. Manchester City                3   1  1  0   3:1     0  0  1   3:4      6:5    +1    4
10. Newport County                 3   1  1  0   4:2     0  0  1   1:2      5:4    +1    4
11. Millwall                       3   1  0  1   3:2     0  1  0   2:2      5:4    +1    4
12. West Bromwich Albion           3   0  0  1   3:4     1  1  0   5:4      8:8          4
13. Bury                           3   1  0  0   3:1     0  1  1   1:4      4:5    -1    4
14. Newcastle United               3   1  0  0   8:1     0  0  2   0:5      8:6    +2    3
15. Chesterfield                   2   1  0  0   2:0     0  0  1   0:2      2:2          3
16. Barnsley                       3   1  0  0   4:1     0  0  2   3:7      7:8    -1    3
17. Southampton                    3   1  0  1   4:3     0  0  1   1:3      5:6    -1    3
18. Sheffield Wednesday            3   1  0  1   3:2     0  0  1   0:3      3:5    -2    3
19. Swansea City                   3   0  0  1   1:2     1  0  1   4:9      5:11   -6    3
20. Burnley                        2   0  1  0   1:1     0  0  1   0:2      1:3    -2    1
21. Fulham                         3   0  1  0   1:1     0  0  2   2:5      3:6    -3    1
22. Bradford Park Avenue           3   0  1  1   2:5     0  0  1   0:2      2:7    -5    1
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Accrington Stanley             3   1  0  0   2:0     2  0  0   4:1      6:1    +5    9
 2. Halifax Town                   3   1  1  0   3:1     1  0  0   3:0      6:1    +5    7
 3. Darlington                     3   1  0  0   1:0     1  1  0   4:2      5:2    +3    7
 4. Chester                        3   2  0  0   3:0     0  1  0   2:2      5:2    +3    7
 5. New Brighton                   3   2  0  0   6:3     0  0  1   0:2      6:5    +1    6
 6. Rochdale                       3   2  0  0   2:0     0  0  1   0:2      2:2          6
 7. Crewe Alexandra                2   0  1  0   0:0     1  0  0   3:0      3:0    +3    4
 8. Wrexham                        3   1  0  0   2:0     0  1  1   1:2      3:2    +1    4
 9. Tranmere Rovers                3   1  0  0   3:1     0  1  1   3:5      6:6          4
10. Lincoln City                   3   1  0  1   4:5     0  1  0   2:2      6:7    -1    4
11. Rotherham United               3   1  1  0   4:3     0  0  1   1:3      5:6    -1    4
12. Carlisle United                2   1  0  0   2:0     0  0  1   1:3      3:3          3
13. Gateshead                      3   1  0  1   3:3     0  0  1   3:4      6:7    -1    3
14. Doncaster Rovers               3   1  0  0   2:0     0  0  2   2:5      4:5    -1    3
15. Oldham Athletic                3   1  0  0   3:1     0  0  2   0:4      3:5    -2    3
16. Hull City                      2   0  1  0   2:2     0  1  0   1:1      3:3          2
17. Southport                      3   0  2  0   4:4     0  0  1   0:1      4:5    -1    2
18. Barrow                         3   0  1  1   3:4     0  1  0   1:1      4:5    -1    2
19. Hartlepool United              3   0  1  0   1:1     0  1  1   0:3      1:4    -3    2
20. York City                      3   0  1  0   2:2     0  0  2   1:3      3:5    -2    1
21. Bradford City                  3   0  0  1   0:2     0  1  1   3:4      3:6    -3    1
22. Stockport County               2   0  0  1   0:3     0  0  1   0:2      0:5    -5    0
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Reading                        3   2  0  0   6:0     0  1  0   2:2      8:2    +6    7
 2. Exeter City                    3   0  1  0   2:2     2  0  0   3:1      5:3    +2    7
 3. Notts County                   2   1  0  0   2:1     1  0  0   4:2      6:3    +3    6
 4. Cardiff City                   3   0  0  1   2:4     2  0  0   3:1      5:5          6
 5. Crystal Palace                 3   1  0  0   3:0     1  0  1   5:9      8:9    -1    6
 6. Ipswich Town                   3   1  1  0   3:1     0  1  0   2:2      5:3    +2    5
 7. Brighton & Hove Albion         3   1  1  0   2:1     0  1  0   3:3      5:4    +1    5
 8. AFC Bournemouth                3   1  1  0  12:2     0  0  1   1:2     13:4    +9    4
 9. Mansfield Town                 3   0  0  1   4:5     1  1  0   4:3      8:8          4
10. Bristol City                   3   0  1  1   4:5     1  0  0   1:0      5:5          4
11. Norwich City                   3   0  0  1   1:2     1  1  0   3:2      4:4          4
12. Walsall                        3   1  0  0   1:0     0  1  1   2:3      3:3          4
13. Southend United                3   1  0  0   3:2     0  1  1   0:1      3:3          4
14. Torquay United                 3   0  2  0   2:2     0  1  0   2:2      4:4          3
15. Leyton Orient                  3   0  2  0   2:2     0  1  0   1:1      3:3          3
16. Northampton Town               3   1  0  1   2:2     0  0  1   0:10     2:12  -10    3
17. Queens Park Rangers            3   0  1  0   2:2     0  1  1   2:3      4:5    -1    2
18. Watford                        3   0  1  1   2:3     0  1  0   2:2      4:5    -1    2
19. Port Vale                      2   0  0  1   0:1     0  1  0   0:0      0:1    -1    1
20. Aldershot                      3   0  0  1   0:1     0  1  1   3:4      3:5    -2    1
21. Swindon Town                   3   0  1  1   2:3     0  0  1   0:1      2:4    -2    1
22. Bristol Rovers                 3   0  1  0   2:2     0  0  2   0:5      2:7    -5    1
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

