

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Portsmouth                    42  18  3  0  52:12    7  5  9  32:30    84:42  +42   83
 2. Derby County                  42  17  2  2  48:22    5  7  9  26:33    74:55  +19   75
 3. Manchester United             42  11  7  3  40:20   10  4  7  37:24    77:44  +33   74
 4. Newcastle United              42  12  5  4  35:29    8  7  6  35:27    70:56  +14   72
 5. Arsenal                       42  13  5  3  51:18    5  8  8  23:26    74:44  +30   67
 6. Wolverhampton Wanderers       42  13  5  3  48:19    4  7 10  31:47    79:66  +13   63
 7. Manchester City               42  10  8  3  28:21    5  7  9  19:30    47:51   -4   60
 8. Aston Villa                   42  10  6  5  40:36    6  4 11  20:40    60:76  -16   58
 9. Stoke City                    42  14  3  4  43:24    2  6 13  23:44    66:68   -2   57
10. Charlton Athletic             42  10  5  6  38:31    5  7  9  25:36    63:67   -4   57
11. Sunderland                    42   8 10  3  27:19    5  7  9  22:39    49:58   -9   56
12. Liverpool                     42   5 10  6  25:18    8  4  9  28:25    53:43  +10   53
13. Bolton Wanderers              42  10  4  7  43:32    4  6 11  16:36    59:68   -9   52
14. Chelsea                       42  10  6  5  43:27    2  8 11  26:41    69:68   +1   50
15. Burnley                       42  10  6  5  27:19    2  8 11  16:31    43:50   -7   50
16. Everton                       42  12  5  4  33:25    1  6 14   8:38    41:63  -22   50
17. Blackpool                     42   8  8  5  24:25    3  8 10  30:42    54:67  -13   49
18. Birmingham City               42   9  7  5  19:10    2  8 11  17:28    36:38   -2   48
19. Huddersfield Town             42   6  7  8  19:24    6  3 12  21:45    40:69  -29   46
20. Middlesbrough                 42  10  6  5  37:23    1  6 14   9:34    46:57  -11   45
21. Preston North End             42   8  6  7  36:36    3  5 13  26:39    62:75  -13   44
22. Sheffield United              42   8  9  4  32:25    3  2 16  25:53    57:78  -21   44
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Fulham                        42  16  4  1  52:14    8  5  8  25:23    77:37  +40   81
 2. West Bromwich Albion          42  16  3  2  47:16    8  5  8  22:23    69:39  +30   80
 3. Southampton                   42  16  4  1  48:10    7  5  9  21:26    69:36  +33   78
 4. Cardiff City                  42  14  4  3  45:21    5  9  7  17:26    62:47  +15   70
 5. Tottenham Hotspur             42  14  4  3  50:18    3 12  6  22:26    72:44  +28   67
 6. West Ham United               42  13  5  3  38:23    5  5 11  18:35    56:58   -2   64
 7. Chesterfield                  42   9  7  5  24:18    6 10  5  27:27    51:45   +6   62
 8. Sheffield Wednesday           42  12  6  3  36:17    3  7 11  27:39    63:56   +7   58
 9. Bury                          42  12  5  4  41:23    5  1 15  26:53    67:76   -9   57
10. Grimsby Town                  42  10  5  6  44:28    5  5 11  28:48    72:76   -4   55
11. Barnsley                      42  10  7  4  40:18    4  5 12  22:43    62:61   +1   54
12. Luton Town                    42  11  6  4  32:16    3  6 12  23:41    55:57   -2   54
13. Blackburn Rovers              42  12  5  4  41:23    3  3 15  12:40    53:63  -10   53
14. Queens Park Rangers           42  11  4  6  31:26    3  7 11  13:36    44:62  -18   53
15. Coventry City                 42  12  3  6  35:20    3  4 14  20:44    55:64   -9   52
16. Bradford Park Avenue          42   8  8  5  37:26    5  3 13  28:52    65:78  -13   50
17. Nottingham Forest             42   9  6  6  22:14    5  1 15  28:40    50:54   -4   49
18. Leeds United                  42  11  6  4  36:21    1  7 13  19:42    55:63   -8   49
19. Plymouth Argyle               42  11  4  6  33:25    1  8 12  16:39    49:64  -15   48
20. Brentford                     42   7 10  4  28:21    4  4 13  14:32    42:53  -11   47
21. Leicester City                42   6 10  5  41:38    4  6 11  21:41    62:79  -17   46
22. Lincoln City                  42   6  7  8  31:35    2  5 14  22:56    53:91  -38   36
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hull City                     42  17  1  3  65:14   10 10  1  28:14    93:28  +65   92
 2. Rotherham United              42  16  4  1  47:17   12  2  7  43:29    90:46  +44   90
 3. Doncaster Rovers              42  10  8  3  26:12   10  2  9  27:28    53:40  +13   70
 4. Darlington                    42  10  3  8  42:36   10  3  8  41:38    83:74   +9   66
 5. Oldham Athletic               42  12  4  5  49:28    6  5 10  26:39    75:67   +8   63
 6. Rochdale                      42  14  3  4  37:16    4  6 11  18:37    55:53   +2   63
 7. Gateshead                     42  10  6  5  41:28    6  7  8  28:30    69:58  +11   61
 8. Wrexham                       42  12  6  3  35:22    5  3 13  21:40    56:62   -6   60
 9. Stockport County              42  13  5  3  44:16    3  6 12  17:40    61:56   +5   59
10. Crewe Alexandra               42  13  4  4  31:18    3  5 13  21:56    52:74  -22   57
11. Mansfield Town                42  13  6  2  39:15    1  8 12  13:33    52:48   +4   56
12. York City                     42  11  3  7  49:28    4  6 11  25:46    74:74        54
13. Barrow                        42  10  8  3  27:13    4  4 13  14:35    41:48   -7   54
14. Tranmere Rovers               42   8  9  4  23:19    5  6 10  23:38    46:57  -11   54
15. Carlisle United               42  12  7  2  46:32    2  4 15  14:45    60:77  -17   53
16. Hartlepool United             42  10  5  6  34:25    4  5 12  11:33    45:58  -13   52
17. New Brighton                  42  10  4  7  25:19    4  4 13  21:39    46:58  -12   50
18. Halifax Town                  42   8  4  9  26:27    4  7 10  19:35    45:62  -17   47
19. Chester                       42  10  7  4  36:19    1  6 14  21:37    57:56   +1   46
20. Accrington Stanley            42  11  4  6  39:23    1  6 14  16:41    55:64   -9   46
21. Southport                     42   6  5 10  24:29    5  4 12  21:35    45:64  -19   42
22. Bradford City                 42   7  6  8  29:31    3  3 15  19:46    48:77  -29   39
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Swansea City                  42  20  1  0  60:11    7  7  7  27:23    87:34  +53   89
 2. Reading                       42  17  1  3  48:18    8  4  9  29:32    77:50  +27   80
 3. AFC Bournemouth               42  15  2  4  42:17    7  6  8  27:31    69:48  +21   74
 4. Swindon Town                  42  11  9  1  38:20    7  6  8  26:36    64:56   +8   69
 5. Bristol Rovers                42  13  5  3  42:23    6  5 10  19:28    61:51  +10   67
 6. Ipswich Town                  42  14  3  4  53:30    4  6 11  25:47    78:77   +1   63
 7. Brighton & Hove Albion        42  11  5  5  32:26    4 13  4  23:29    55:55        63
 8. Notts County                  42  15  3  3  68:19    4  2 15  34:49   102:68  +34   62
 9. Millwall                      42  12  7  2  42:23    5  4 12  21:41    63:64   -1   62
10. Torquay United                42  12  5  4  45:26    5  6 10  20:44    65:70   -5   62
11. Norwich City                  42  11  6  4  32:10    5  6 10  35:39    67:49  +18   60
12. Exeter City                   42  12  5  4  45:26    3  5 13  18:50    63:76  -13   55
13. Port Vale                     42  11  3  7  32:21    3  8 10  19:33    51:54   -3   53
14. Walsall                       42   9  5  7  34:28    6  3 12  22:36    56:64   -8   53
15. Newport County                42   8  6  7  41:35    6  3 12  27:57    68:92  -24   51
16. Bristol City                  42   8  9  4  28:24    3  5 13  16:38    44:62  -18   47
17. Northampton Town              42   9  6  6  33:20    3  3 15  18:42    51:62  -11   45
18. Watford                       42   6  9  6  24:21    4  6 11  17:33    41:54  -13   45
19. Leyton Orient                 42   9  6  6  36:29    2  6 13  22:51    58:80  -22   45
20. Aldershot                     42   6  5 10  26:29    5  6 10  22:30    48:59  -11   44
21. Southend United               42   5 10  6  18:18    4  6 11  23:28    41:46   -5   43
22. Crystal Palace                42   7  8  6  27:27    1  3 17  11:49    38:76  -38   35
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

