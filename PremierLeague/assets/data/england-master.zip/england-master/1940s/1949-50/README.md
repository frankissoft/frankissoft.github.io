

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Portsmouth                    42  12  7  2  44:15   10  2  9  30:23    74:38  +36   75
 2. Wolverhampton Wanderers       42  11  8  2  47:21    9  5  7  29:28    76:49  +27   73
 3. Sunderland                    42  14  6  1  50:23    7  4 10  33:39    83:62  +21   73
 4. Newcastle United              42  14  4  3  49:23    5  8  8  28:32    77:55  +22   69
 5. Manchester United             42  11  5  5  42:20    7  9  5  27:24    69:44  +25   68
 6. Arsenal                       42  12  4  5  48:24    7  7  7  31:31    79:55  +24   68
 7. Middlesbrough                 42  14  2  5  37:18    6  5 10  22:30    59:48  +11   67
 8. Blackpool                     42  10  8  3  29:14    7  7  7  17:21    46:35  +11   66
 9. Liverpool                     42  10  7  4  37:23    7  7  7  27:31    64:54  +10   65
10. Derby County                  42  11  5  5  46:26    6  5 10  23:35    69:61   +8   61
11. Burnley                       42   9  7  5  23:17    7  6  8  17:23    40:40        61
12. Aston Villa                   42  10  7  4  31:19    5  5 11  30:42    61:61        57
13. West Bromwich Albion          42   9  7  5  28:16    5  5 11  19:37    47:53   -6   54
14. Chelsea                       42   7  7  7  31:30    5  9  7  27:35    58:65   -7   52
15. Huddersfield Town             42  11  4  6  34:22    3  5 13  18:51    52:73  -21   51
16. Charlton Athletic             42   7  5  9  33:35    6  1 14  20:30    53:65  -12   45
17. Stoke City                    42  10  4  7  27:28    1  8 12  18:47    45:75  -30   45
18. Fulham                        42   8  6  7  24:19    2  8 11  17:35    41:54  -13   44
19. Bolton Wanderers              42  10  5  6  34:22    0  9 12  11:37    45:59  -14   44
20. Everton                       42   6  8  7  24:20    4  6 11  18:46    42:66  -24   44
21. Manchester City               42   7  8  6  27:24    1  5 15   9:44    36:68  -32   37
22. Birmingham City               42   6  8  7  19:24    1  6 14  12:43    31:67  -36   35
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Tottenham Hotspur             42  15  3  3  51:15   12  4  5  30:20    81:35  +46   88
 2. Sheffield United              42   9 10  2  36:19   10  4  7  32:30    68:49  +19   71
 3. Southampton                   42  13  4  4  44:25    6 10  5  20:23    64:48  +16   71
 4. Sheffield Wednesday           42  12  7  2  46:23    6  9  6  21:25    67:48  +19   70
 5. Leeds United                  42  11  8  2  33:16    6  5 10  21:29    54:45   +9   64
 6. Preston North End             42  12  5  4  37:21    6  4 11  23:28    60:49  +11   63
 7. Hull City                     42  11  8  2  39:25    6  3 12  25:47    64:72   -8   62
 8. Swansea City                  42  11  3  7  34:18    6  6  9  19:31    53:49   +4   60
 9. Cardiff City                  42  13  3  5  28:14    3  7 11  13:30    41:44   -3   58
10. Brentford                     42  11  5  5  21:12    4  8  9  23:37    44:49   -5   58
11. Grimsby Town                  42  13  5  3  53:25    3  3 15  21:48    74:73   +1   56
12. Chesterfield                  42  12  3  6  28:16    3  6 12  15:31    43:47   -4   54
13. Coventry City                 42   8  6  7  32:24    5  7  9  23:31    55:55        52
14. Barnsley                      42  11  6  4  45:28    2  7 12  19:39    64:67   -3   52
15. Blackburn Rovers              42  10  5  6  30:15    4  5 12  25:45    55:60   -5   52
16. Bury                          42  10  8  3  37:19    4  1 16  23:46    60:65   -5   51
17. Leicester City                42   8  9  4  30:25    4  6 11  25:40    55:65  -10   51
18. West Ham United               42   8  7  6  30:25    4  5 12  23:36    53:61   -8   48
19. Luton Town                    42   8  9  4  28:22    2  9 10  13:29    41:51  -10   48
20. Queens Park Rangers           42   6  5 10  21:30    5  7  9  19:27    40:57  -17   45
21. Bradford Park Avenue          42   7  6  8  34:34    3  5 13  17:43    51:77  -26   41
22. Plymouth Argyle               42   6  6  9  19:24    2 10  9  25:41    44:65  -21   40
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Gateshead                     42  13  5  3  51:23   10  2  9  36:31    87:54  +33   76
 2. Doncaster Rovers              42   9  9  3  30:15   10  8  3  36:23    66:38  +28   74
 3. Rochdale                      42  15  3  3  42:13    6  6  9  26:28    68:41  +27   72
 4. Lincoln City                  42  14  5  2  35:9     7  4 10  25:30    60:39  +21   72
 5. Tranmere Rovers               42  15  3  3  35:21    4  8  9  16:27    51:48   +3   68
 6. Rotherham United              42  10  6  5  46:28    9  4  8  34:31    80:59  +21   67
 7. Mansfield Town                42  12  4  5  37:20    6  8  7  29:34    66:54  +12   66
 8. Crewe Alexandra               42  10  6  5  38:27    7  8  6  30:28    68:55  +13   65
 9. Stockport County              42  14  2  5  33:21    5  5 11  22:31    55:52   +3   64
10. Carlisle United               42  12  6  3  39:20    4  9  8  28:31    67:51  +16   63
11. Oldham Athletic               42  10  4  7  32:31    6  7  8  26:32    58:63   -5   59
12. Chester                       42  12  3  6  47:32    5  3 13  23:46    70:78   -8   57
13. Accrington Stanley            42  12  5  4  41:21    4  2 15  16:41    57:62   -5   55
14. New Brighton                  42  10  5  6  27:25    4  5 12  18:38    45:63  -18   52
15. Barrow                        42   9  6  6  27:20    5  3 13  20:33    47:53   -6   51
16. Southport                     42   7 10  4  29:26    5  3 13  22:45    51:71  -20   49
17. Hartlepool United             42  10  3  8  37:35    4  2 15  15:44    52:79  -27   47
18. Darlington                    42   9  8  4  35:27    2  5 14  21:42    56:69  -13   46
19. Bradford City                 42  11  1  9  38:32    1  7 13  23:44    61:76  -15   44
20. Halifax Town                  42   9  5  7  35:31    3  3 15  23:54    58:85  -27   44
21. Wrexham                       42   8  7  6  24:17    2  5 14  15:37    39:54  -15   42
22. York City                     42   6  7  8  29:33    3  6 12  23:37    52:70  -18   40
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Notts County                  42  17  3  1  60:12    8  5  8  35:38    95:50  +45   83
 2. Northampton Town              42  12  6  3  43:21    8  5  8  29:29    72:50  +22   71
 3. Southend United               42  15  4  2  43:15    4  9  8  23:33    66:48  +18   70
 4. Nottingham Forest             42  13  0  8  37:15    7  9  5  30:24    67:39  +28   69
 5. Torquay United                42  13  6  2  40:23    6  4 11  26:40    66:63   +3   67
 6. Bristol Rovers                42  12  5  4  34:18    7  0 14  17:33    51:51        62
 7. Watford                       42  10  6  5  26:13    6  7  8  19:22    45:35  +10   61
 8. Brighton & Hove Albion        42   9  8  4  32:24    7  4 10  25:45    57:69  -12   60
 9. Reading                       42  15  2  4  48:21    2  6 13  22:43    70:64   +6   59
10. Crystal Palace                42  12  5  4  35:21    3  9  9  20:33    55:54   +1   59
11. Norwich City                  42  11  5  5  44:21    5  5 11  21:42    65:63   +2   58
12. AFC Bournemouth               42  11  6  4  38:19    5  4 12  19:37    57:56   +1   58
13. Port Vale                     42  12  6  3  33:13    3  5 13  14:29    47:42   +5   56
14. Swindon Town                  42   9  7  5  41:30    6  4 11  18:32    59:62   -3   56
15. Bristol City                  42  12  4  5  38:19    3  6 12  22:42    60:61   -1   55
16. Exeter City                   42   9  8  4  37:27    5  3 13  26:48    63:75  -12   53
17. Aldershot                     42  10  5  6  30:16    3  3 15  18:44    48:60  -12   47
18. Ipswich Town                  42   9  6  6  36:36    3  5 13  21:50    57:86  -29   47
19. Newport County                42  11  5  5  50:34    2  3 16  17:64    67:98  -31   47
20. Leyton Orient                 42  10  6  5  33:30    2  5 14  20:55    53:85  -32   47
21. Millwall                      42  11  1  9  39:29    3  3 15  16:34    55:63   -8   46
22. Walsall                       42   8  8  5  37:25    1  8 12  24:37    61:62   -1   43
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

