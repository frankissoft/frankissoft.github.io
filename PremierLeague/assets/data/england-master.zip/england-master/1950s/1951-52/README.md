

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             42  15  3  3  55:21    8  8  5  40:31    95:52  +43   80
 2. Tottenham Hotspur             42  16  1  4  45:20    6  8  7  31:31    76:51  +25   75
 3. Arsenal                       42  13  7  1  54:30    8  4  9  26:31    80:61  +19   74
 4. Portsmouth                    42  13  3  5  42:25    7  5  9  26:33    68:58  +10   68
 5. Bolton Wanderers              42  11  7  3  35:26    8  3 10  30:35    65:61   +4   67
 6. Aston Villa                   42  13  3  5  49:28    6  6  9  30:42    79:70   +9   66
 7. Newcastle United              42  12  4  5  62:28    6  5 10  36:45    98:73  +25   63
 8. Preston North End             42  10  5  6  39:22    7  7  7  35:32    74:54  +20   63
 9. Blackpool                     42  12  5  4  40:27    6  4 11  24:37    64:64        63
10. Charlton Athletic             42  12  5  4  41:24    5  5 11  27:39    68:63   +5   61
11. Sunderland                    42   8  6  7  41:28    7  6  8  29:33    70:61   +9   57
12. West Bromwich Albion          42   8  9  4  38:29    6  4 11  36:48    74:77   -3   55
13. Liverpool                     42   6 11  4  31:25    6  8  7  26:36    57:61   -4   55
14. Burnley                       42   9  6  6  32:19    6  4 11  24:44    56:63   -7   55
15. Manchester City               42   7  5  9  29:28    6  8  7  29:33    58:61   -3   52
16. Derby County                  42  10  4  7  43:37    5  3 13  20:43    63:80  -17   52
17. Middlesbrough                 42  12  4  5  37:25    3  2 16  27:63    64:88  -24   51
18. Wolverhampton Wanderers       42   8  6  7  40:33    4  8  9  33:40    73:73        50
19. Chelsea                       42  10  3  8  31:29    4  5 12  21:43    52:72  -20   50
20. Stoke City                    42   8  6  7  34:32    4  1 16  15:56    49:88  -39   43
21. Huddersfield Town             42   9  3  9  32:35    1  5 15  17:47    49:82  -33   38
22. Fulham                        42   5  7  9  38:31    3  4 14  20:46    58:77  -19   35
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield Wednesday           42  14  4  3  54:23    7  7  7  46:43   100:66  +34   74
 2. Birmingham City               42  11  6  4  36:21   10  3  8  31:35    67:56  +11   72
 3. Cardiff City                  42  18  2  1  52:15    2  9 10  20:39    72:54  +18   71
 4. Nottingham Forest             42  12  6  3  41:22    6  7  8  36:40    77:62  +15   67
 5. Leicester City                42  12  6  3  48:24    7  3 11  30:40    78:64  +14   66
 6. Leeds United                  42  13  7  1  35:15    5  4 12  24:42    59:57   +2   65
 7. Everton                       42  12  5  4  42:25    5  5 11  22:33    64:58   +6   61
 8. Luton Town                    42   9  7  5  46:35    7  5  9  31:43    77:78   -1   60
 9. Sheffield United              42  13  2  6  57:28    5  3 13  33:48    90:76  +14   59
10. Rotherham United              42  11  4  6  40:25    6  4 11  33:46    73:71   +2   59
11. Brentford                     42  11  7  3  34:20    4  5 12  20:35    54:55   -1   57
12. Blackburn Rovers              42  11  3  7  35:30    6  3 12  19:33    54:63   -9   57
13. West Ham United               42  13  5  3  48:29    2  6 13  19:48    67:77  -10   56
14. Southampton                   42  11  6  4  40:25    4  5 12  21:48    61:73  -12   56
15. Notts County                  42  11  5  5  45:27    5  2 14  26:41    71:68   +3   55
16. Bury                          42  13  2  6  43:22    2  5 14  24:47    67:69   -2   52
17. Doncaster Rovers              42   9  4  8  29:28    4  8  9  26:32    55:60   -5   51
18. Hull City                     42  11  5  5  44:23    2  6 13  16:47    60:70  -10   50
19. Swansea City                  42  10  4  7  45:26    2  8 11  27:50    72:76   -4   48
20. Coventry City                 42   9  5  7  36:33    5  1 15  23:49    59:82  -23   48
21. Barnsley                      42   8  7  6  39:33    3  7 11  20:39    59:72  -13   47
22. Queens Park Rangers           42   8  8  5  35:35    3  4 14  17:46    52:81  -29   45
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Lincoln City                  46  19  2  2  80:23   11  7  5  41:29   121:52  +69   99
 2. Grimsby Town                  46  19  2  2  59:14   10  6  7  37:31    96:45  +51   95
 3. Stockport County              46  12  9  2  47:17   11  4  8  27:23    74:40  +34   82
 4. Oldham Athletic               46  19  2  2  65:22    5  7 11  25:39    90:61  +29   81
 5. Gateshead                     46  14  7  2  41:17    7  4 12  25:32    66:49  +17   74
 6. Mansfield Town                46  17  3  3  50:23    5  5 13  23:37    73:60  +13   74
 7. Hartlepool United             46  17  3  3  47:19    4  5 14  24:46    71:65   +6   71
 8. Carlisle United               46  10  7  6  31:24    9  6  8  31:33    62:57   +5   70
 9. Bradford Park Avenue          46  13  6  4  51:28    6  6 11  23:36    74:64  +10   69
10. Tranmere Rovers               46  17  2  4  59:29    4  4 15  17:42    76:71   +5   69
11. York City                     46  16  4  3  53:19    2  9 12  20:33    73:52  +21   67
12. Barrow                        46  13  5  5  33:19    4  7 12  24:42    57:61   -4   63
13. Chesterfield                  46  15  7  1  47:16    2  4 17  18:50    65:66   -1   62
14. Crewe Alexandra               46  12  6  5  42:28    5  2 16  21:54    63:82  -19   59
15. Bradford City                 46  12  5  6  40:32    4  5 14  21:36    61:68   -7   58
16. Scunthorpe United             46  10 11  2  39:23    4  5 14  26:51    65:74   -9   58
17. Southport                     46  12  6  5  36:22    3  5 15  17:49    53:71  -18   56
18. Wrexham                       46  14  5  4  41:22    1  4 18  22:51    63:73  -10   54
19. Chester                       46  13  4  6  46:30    2  5 16  26:55    72:85  -13   54
20. Halifax Town                  46  11  4  8  31:23    3  3 17  30:74    61:97  -36   49
21. Rochdale                      46  10  5  8  32:34    1  8 14  15:45    47:79  -32   46
22. Accrington Stanley            46   6  8  9  30:34    4  4 15  31:58    61:92  -31   42
23. Darlington                    46  10  5  8  39:34    1  4 18  25:69    64:103 -39   42
24. Workington                    46   8  4 11  33:34    3  3 17  17:57    50:91  -41   40
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Plymouth Argyle               46  19  3  1  70:19   10  5  8  37:34   107:53  +54   95
 2. Reading                       46  19  2  2  73:23   10  1 12  39:37   112:60  +52   90
 3. Norwich City                  46  18  1  4  55:14    8  8  7  34:35    89:49  +40   87
 4. Brighton & Hove Albion        46  15  4  4  57:24    9  6  8  30:39    87:63  +24   82
 5. Millwall                      46  16  5  2  46:21    7  7  9  28:32    74:53  +21   81
 6. Newport County                46  13  7  3  45:26    8  5 10  32:50    77:76   +1   75
 7. Bristol Rovers                46  14  5  4  60:20    6  7 10  29:33    89:53  +36   72
 8. Northampton Town              46  17  1  5  65:31    5  4 14  28:43    93:74  +19   71
 9. Southend United               46  16  6  1  56:17    3  4 16  19:49    75:66   +9   67
10. Colchester United             46  12  7  4  32:22    5  5 13  24:55    56:77  -21   63
11. Aldershot                     46  11  4  8  40:27    7  4 12  38:62    78:89  -11   62
12. Torquay United                46  10  3 10  53:42    7  7  9  33:56    86:98  -12   61
13. AFC Bournemouth               46  11  4  8  42:30    5  6 12  27:45    69:75   -6   58
14. Ipswich Town                  46  12  4  7  45:31    4  5 14  18:43    63:74  -11   57
15. Bristol City                  46  13  6  4  44:26    2  6 15  14:43    58:69  -11   57
16. Leyton Orient                 46  12  5  6  39:26    4  4 15  16:42    55:68  -13   57
17. Port Vale                     46  11 11  1  33:16    3  4 16  17:50    50:66  -16   57
18. Swindon Town                  46   9  9  5  29:22    5  5 13  22:46    51:68  -17   56
19. Crystal Palace                46   9  7  7  32:28    6  2 15  29:52    61:80  -19   54
20. Watford                       46   7  7  9  34:37    6  3 14  23:44    57:81  -24   49
21. Shrewsbury Town               46  11  3  9  35:29    2  7 14  26:57    61:86  -25   49
22. Exeter City                   46  10  4  9  40:36    3  5 15  25:50    65:86  -21   48
23. Gillingham                    46  10  7  6  47:31    1  6 16  24:50    71:81  -10   46
24. Walsall                       46  11  3  9  38:31    2  2 19  17:63    55:94  -39   44
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

