

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             42  18  3  0  51:20    7  7  7  32:31    83:51  +32   85
 2. Wolverhampton Wanderers       42  15  2  4  51:27    5  7  9  38:38    89:65  +24   69
 3. Blackpool                     42  13  4  4  56:27    7  5  9  30:35    86:62  +24   69
 4. Manchester City               42  11  5  5  40:27    7  5  9  42:42    82:69  +13   64
 5. Arsenal                       42  13  4  4  38:22    5  6 10  22:39    60:61   -1   64
 6. Birmingham City               42  12  4  5  51:26    6  5 10  24:31    75:57  +18   63
 7. Burnley                       42  11  3  7  37:20    7  5  9  27:34    64:54  +10   62
 8. Bolton Wanderers              42  13  3  5  50:24    5  4 12  21:34    71:58  +13   61
 9. Sunderland                    42  10  8  3  44:36    7  1 13  36:59    80:95  -15   60
10. Luton Town                    42  12  4  5  44:27    5  4 12  22:37    66:64   +2   59
11. West Bromwich Albion          42  13  3  5  37:25    5  2 14  21:45    58:70  -12   59
12. Newcastle United              42  12  4  5  49:24    5  3 13  36:46    85:70  +15   58
13. Charlton Athletic             42  13  2  6  47:26    4  4 13  28:55    75:81   -6   57
14. Portsmouth                    42   9  8  4  46:38    7  1 13  32:47    78:85   -7   57
15. Everton                       42  11  5  5  37:29    4  5 12  18:40    55:69  -14   55
16. Cardiff City                  42  11  4  6  36:32    4  5 12  19:37    55:69  -14   54
17. Chelsea                       42  10  4  7  32:26    4  7 10  32:51    64:77  -13   53
18. Tottenham Hotspur             42   9  4  8  37:33    6  3 12  24:38    61:71  -10   52
19. Preston North End             42   6  5 10  32:36    8  3 10  41:36    73:72   +1   50
20. Huddersfield Town             42   9  4  8  32:30    5  3 13  22:53    54:83  -29   49
21. Aston Villa                   42   9  6  6  32:29    2  7 12  20:40    52:69  -17   46
22. Sheffield United              42   8  6  7  31:35    4  3 14  32:42    63:77  -14   45
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield Wednesday           42  13  5  3  60:28    8  8  5  41:34   101:62  +39   76
 2. Leeds United                  42  17  3  1  51:18    6  3 12  29:42    80:60  +20   75
 3. Liverpool                     42  14  3  4  52:25    7  3 11  33:38    85:63  +22   69
 4. Blackburn Rovers              42  13  4  4  55:29    8  2 11  29:36    84:65  +19   69
 5. Leicester City                42  15  3  3  63:23    6  3 12  31:55    94:78  +16   69
 6. Bristol Rovers                42  13  3  5  53:33    8  3 10  31:37    84:70  +14   69
 7. Fulham                        42  15  2  4  59:27    5  4 12  30:52    89:79  +10   66
 8. Nottingham Forest             42   9  5  7  30:26   10  4  7  38:37    68:63   +5   66
 9. Swansea City                  42  14  4  3  49:23    6  2 13  34:58    83:81   +2   66
10. Bristol City                  42  14  4  3  49:20    5  3 13  31:44    80:64  +16   64
11. Lincoln City                  42  14  5  2  49:17    4  5 12  30:48    79:65  +14   64
12. Stoke City                    42  13  2  6  47:27    7  2 12  24:35    71:62   +9   64
13. Port Vale                     42  12  4  5  38:21    4  9  8  22:37    60:58   +2   61
14. Middlesbrough                 42  11  4  6  46:31    5  4 12  30:47    76:78   -2   56
15. Bury                          42   9  5  7  44:39    7  3 11  42:51    86:90   -4   56
16. West Ham United               42  12  4  5  52:27    2  7 12  22:42    74:69   +5   53
17. Doncaster Rovers              42  11  5  5  45:30    1  6 14  24:66    69:96  -27   47
18. Rotherham United              42   7  5  9  29:34    5  4 12  27:41    56:75  -19   45
19. Barnsley                      42  10  5  6  33:35    1  7 13  14:49    47:84  -37   45
20. Notts County                  42   8  5  8  39:37    3  4 14  16:45    55:82  -27   42
21. Plymouth Argyle               42   7  6  8  33:25    3  2 16  21:62    54:87  -33   38
22. Hull City                     42   6  4 11  32:45    4  2 15  21:52    53:97  -44   36
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Grimsby Town                  46  20  1  2  54:10   11  5  7  22:19    76:29  +47   99
 2. Derby County                  46  18  4  1  67:23   10  3 10  43:32   110:55  +55   91
 3. Accrington Stanley            46  17  4  2  61:19    8  5 10  31:38    92:57  +35   84
 4. Hartlepool United             46  18  2  3  47:15    8  3 12  34:45    81:60  +21   83
 5. Southport                     46  12  9  2  39:18   11  2 10  27:35    66:53  +13   80
 6. Chesterfield                  46  18  1  4  61:21    7  3 13  33:45    94:66  +28   79
 7. Stockport County              46  16  4  3  65:22    5  5 13  25:39    90:61  +29   72
 8. Scunthorpe United             46  12  4  7  40:26    8  4 11  35:37    75:63  +12   68
 9. Bradford City                 46  16  5  2  57:25    2  8 13  21:39    78:64  +14   67
10. York City                     46  12  4  7  44:24    7  5 11  41:48    85:72  +13   66
11. Workington                    46  13  4  6  47:20    6  5 12  28:43    75:63  +12   66
12. Rochdale                      46  13  5  5  46:39    4  8 11  20:45    66:84  -18   64
13. Gateshead                     46  15  4  4  56:32    2  7 14  21:52    77:84   -7   62
14. Wrexham                       46  11  5  7  37:28    5  5 13  29:45    66:73   -7   58
15. Darlington                    46  11  6  6  41:28    5  3 15  19:45    60:73  -13   57
16. Tranmere Rovers               46  11  4  8  33:25    5  5 13  26:59    59:84  -25   57
17. Mansfield Town                46  13  6  4  59:21    1  5 17  25:60    84:81   +3   53
18. Halifax Town                  46  10  6  7  40:27    4  5 14  26:49    66:76  -10   53
19. Carlisle United               46  11  3  9  45:36    4  5 14  26:59    71:95  -24   53
20. Chester                       46  10  8  5  35:33    3  6 14  17:49    52:82  -30   53
21. Oldham Athletic               46   7 12  4  48:36    3  6 14  28:50    76:86  -10   48
22. Bradford Park Avenue          46  13  4  6  47:38    0  3 20  14:84    61:122 -61   46
23. Barrow                        46  11  6  6  44:25    1  3 19  17:58    61:83  -22   45
24. Crewe Alexandra               46   9  4 10  32:35    0  6 17  18:70    50:105 -55   37
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leyton Orient                 46  18  3  2  76:20   11  5  7  30:29   106:49  +57   95
 2. Brighton & Hove Albion        46  20  2  1  73:16    9  5  9  39:34   112:50  +62   94
 3. Ipswich Town                  46  16  6  1  59:28    9  8  6  47:32   106:60  +46   89
 4. Southend United               46  16  4  3  58:25    5  7 11  30:55    88:80   +8   74
 5. Torquay United                46  11 10  2  48:21    9  2 12  38:42    86:63  +23   72
 6. Brentford                     46  11  8  4  40:30    8  6  9  29:36    69:66   +3   71
 7. Norwich City                  46  15  4  4  56:31    4  9 10  30:51    86:82   +4   70
 8. Coventry City                 46  16  4  3  54:20    4  5 14  19:40    73:60  +13   69
 9. AFC Bournemouth               46  13  6  4  39:14    6  4 13  24:37    63:51  +12   67
10. Gillingham                    46  12  3  8  38:28    7  7  9  31:43    69:71   -2   67
11. Northampton Town              46  14  3  6  44:27    6  4 13  23:44    67:71   -4   67
12. Colchester United             46  14  4  5  56:37    4  7 12  20:44    76:81   -5   65
13. Shrewsbury Town               46  12  9  2  47:21    5  3 15  22:45    69:66   +3   63
14. Southampton                   46  13  6  4  60:30    5  2 16  31:51    91:81  +10   62
15. Exeter City                   46  10  6  7  39:30    5  4 14  19:47    58:77  -19   55
16. Reading                       46  10  2 11  40:37    5  7 11  30:42    70:79   -9   54
17. Newport County                46  12  2  9  32:26    3  7 13  26:53    58:79  -21   54
18. Walsall                       46  13  5  5  43:28    2  3 18  25:56    68:84  -16   53
19. Queens Park Rangers           46  10  7  6  44:32    4  4 15  20:54    64:86  -22   53
20. Aldershot                     46   9  9  5  36:33    3  7 13  34:57    70:90  -20   52
21. Millwall                      46  13  4  6  56:31    2  2 19  27:69    83:100 -17   51
22. Watford                       46   8  5 10  31:39    5  6 12  21:46    52:85  -33   50
23. Crystal Palace                46   7  3 13  27:32    5  7 11  27:51    54:83  -29   46
24. Swindon Town                  46   4 10  9  18:22    4  4 15  16:56    34:78  -44   38
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

