

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Tottenham Hotspur             42  15  3  3  65:28   16  1  4  50:27   115:55  +60   97
 2. Wolverhampton Wanderers       42  17  2  2  61:32    8  5  8  42:43   103:75  +28   82
 3. Sheffield Wednesday           42  15  4  2  45:17    8  8  5  33:30    78:47  +31   81
 4. Burnley                       42  11  4  6  58:40   11  3  7  44:37   102:77  +25   73
 5. Everton                       42  13  4  4  47:23    9  2 10  40:46    87:69  +18   72
 6. Leicester City                42  12  4  5  54:31    6  5 10  33:39    87:70  +17   63
 7. Manchester United             42  14  5  2  58:20    4  4 13  30:56    88:76  +12   63
 8. Aston Villa                   42  13  3  5  48:28    4  6 11  30:49    78:77   +1   60
 9. West Bromwich Albion          42  10  3  8  43:32    8  2 11  24:39    67:71   -4   59
10. Blackburn Rovers              42  12  3  6  48:34    3 10  8  29:42    77:76   +1   58
11. Arsenal                       42  12  3  6  44:35    3  8 10  33:50    77:85   -8   56
12. Chelsea                       42  10  5  6  61:48    5  2 14  37:52    98:100  -2   52
13. Nottingham Forest             42   8  7  6  34:33    6  2 13  28:45    62:78  -16   51
14. Manchester City               42  10  5  6  41:30    3  6 12  38:60    79:90  -11   50
15. Fulham                        42   8  8  5  39:39    6  0 15  33:56    72:95  -23   50
16. Cardiff City                  42  11  5  5  34:26    2  6 13  26:59    60:85  -25   50
17. West Ham United               42  12  4  5  53:31    1  6 14  24:57    77:88  -11   49
18. Birmingham City               42  10  4  7  35:31    4  2 15  27:53    62:84  -22   48
19. Bolton Wanderers              42   9  5  7  38:29    3  6 12  20:44    58:73  -15   47
20. Blackpool                     42   9  3  9  44:34    3  6 12  24:39    68:73   -5   45
21. Newcastle United              42   7  7  7  51:49    4  3 14  35:60    86:109 -23   43
22. Preston North End             42   7  6  8  28:25    3  4 14  15:46    43:71  -28   40
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Ipswich Town                  42  15  3  3  55:24   11  4  6  45:31   100:55  +45   85
 2. Sheffield United              42  16  2  3  49:22   10  4  7  32:29    81:51  +30   84
 3. Liverpool                     42  14  5  2  49:21    7  5  9  38:37    87:58  +29   73
 4. Norwich City                  42  15  3  3  46:20    5  6 10  24:33    70:53  +17   69
 5. Middlesbrough                 42  13  6  2  44:20    5  6 10  39:54    83:74   +9   66
 6. Swansea City                  42  14  4  3  49:26    4  7 10  28:47    77:73   +4   65
 7. Sunderland                    42  12  5  4  47:24    5  8  8  28:36    75:60  +15   64
 8. Southampton                   42  12  4  5  57:35    6  4 11  27:46    84:81   +3   62
 9. Charlton Athletic             42  12  3  6  60:41    4  8  9  37:49    97:90   +7   59
10. Plymouth Argyle               42  13  4  4  52:32    4  4 13  29:50    81:82   -1   59
11. Scunthorpe United             42   9  8  4  39:25    5  7  9  30:39    69:64   +5   57
12. Derby County                  42   9  6  6  46:35    6  4 11  34:45    80:80        55
13. Luton Town                    42  13  5  3  48:27    2  4 15  22:52    70:79   -9   54
14. Leeds United                  42   7  7  7  41:38    7  3 11  34:45    75:83   -8   52
15. Bristol Rovers                42  13  4  4  52:35    2  3 16  21:57    73:92  -19   52
16. Brighton & Hove Albion        42   9  6  6  33:26    5  3 13  28:49    61:75  -14   51
17. Leyton Orient                 42  10  5  6  31:29    4  3 14  24:49    55:78  -23   50
18. Rotherham United              42   9  7  5  37:24    3  6 12  28:40    65:64   +1   49
19. Stoke City                    42   9  6  6  39:26    3  6 12  12:33    51:59   -8   48
20. Huddersfield Town             42   7  5  9  33:33    6  4 11  29:38    62:71   -9   48
21. Portsmouth                    42  10  6  5  38:27    1  5 15  26:64    64:91  -27   44
22. Lincoln City                  42   5  4 12  30:43    3  4 14  18:52    48:95  -47   32
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bury                          46  18  3  2  62:17   12  5  6  46:28   108:45  +63   98
 2. Walsall                       46  19  4  0  62:20    9  2 12  36:40    98:60  +38   90
 3. Queens Park Rangers           46  18  4  1  58:23    7  6 10  35:37    93:60  +33   85
 4. Watford                       46  12  7  4  52:27    8  5 10  33:45    85:72  +13   72
 5. Notts County                  46  16  3  4  52:24    5  6 12  30:53    82:77   +5   72
 6. Grimsby Town                  46  14  4  5  48:32    6  6 11  29:37    77:69   +8   70
 7. Barnsley                      46  15  5  3  56:30    6  2 15  27:50    83:80   +3   70
 8. Port Vale                     46  15  3  5  63:30    2 12  9  33:49    96:79  +17   66
 9. Halifax Town                  46  14  7  2  42:22    2 10 11  29:56    71:78   -7   65
10. Hull City                     46  13  6  4  51:28    4  6 13  22:45    73:73        63
11. Newport County                46  12  7  4  51:30    5  4 14  30:60    81:90   -9   62
12. Shrewsbury Town               46  13  7  3  54:26    2  9 12  29:49    83:75   +8   61
13. Bristol City                  46  15  4  4  50:19    2  6 15  20:49    70:68   +2   61
14. Coventry City                 46  14  6  3  54:25    2  6 15  26:58    80:83   -3   60
15. Torquay United                46   8 12  3  37:26    6  5 12  38:57    75:83   -8   59
16. Swindon Town                  46  13  6  4  41:16    1  9 13  21:39    62:55   +7   57
17. Brentford                     46  10  9  4  41:28    3  8 12  15:42    56:70  -14   56
18. AFC Bournemouth               46   8  7  8  34:39    7  3 13  24:37    58:76  -18   55
19. Reading                       46  13  5  5  48:29    1  7 15  24:54    72:83  -11   54
20. Southend United               46  10  8  5  38:26    4  3 16  22:50    60:76  -16   53
21. Tranmere Rovers               46  11  5  7  53:50    4  3 16  26:65    79:115 -36   53
22. Bradford City                 46   8  8  7  37:36    3  6 14  28:51    65:87  -22   47
23. Colchester United             46   8  5 10  40:44    3  6 14  28:57    68:101 -33   44
24. Chesterfield                  46   9  6  8  42:29    1  6 16  25:58    67:87  -20   42
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Peterborough United           46  18  3  2  85:30   10  7  6  49:35   134:65  +69   94
 2. Crystal Palace                46  16  4  3  64:28   13  2  8  46:41   110:69  +41   93
 3. Bradford Park Avenue          46  16  5  2  49:22   10  3 10  35:52    84:74  +10   86
 4. Northampton Town              46  16  4  3  53:25    9  6  8  37:37    90:62  +28   85
 5. York City                     46  17  3  3  50:14    4  6 13  30:46    80:60  +20   72
 6. Millwall                      46  13  3  7  56:33    8  5 10  41:53    97:86  +11   71
 7. Workington                    46  14  3  6  38:28    7  4 12  36:48    74:76   -2   70
 8. Crewe Alexandra               46  11  4  8  40:29    9  5  9  21:38    61:67   -6   69
 9. Darlington                    46  11  7  5  41:24    7  6 10  37:46    78:70   +8   67
10. Doncaster Rovers              46  15  0  8  52:33    4  7 12  24:45    76:78   -2   64
11. Oldham Athletic               46  13  4  6  57:38    6  3 14  22:50    79:88   -9   64
12. Aldershot                     46  16  4  3  55:19    2  5 16  24:50    79:69  +10   63
13. Southport                     46  12  6  5  47:27    7  0 16  22:40    69:67   +2   63
14. Stockport County              46  14  4  5  31:21    4  5 14  26:45    57:66   -9   63
15. Wrexham                       46  12  4  7  38:22    5  4 14  24:34    62:56   +6   59
16. Rochdale                      46  13  7  3  43:19    4  1 18  17:47    60:66   -6   59
17. Gillingham                    46   9  7  7  45:34    6  6 11  19:32    64:66   -2   58
18. Accrington Stanley            46  12  4  7  44:32    4  4 15  30:56    74:88  -14   56
19. Mansfield Town                46  10  3 10  39:34    6  3 14  32:44    71:78   -7   54
20. Carlisle United               46  10  7  6  43:37    3  6 14  18:42    61:79  -18   52
21. Exeter City                   46  12  3  8  39:32    2  7 14  27:62    66:94  -28   52
22. Barrow                        46  10  6  7  33:28    3  5 15  19:51    52:79  -27   50
23. Hartlepool United             46  10  4  9  46:40    2  4 17  25:63    71:103 -32   44
24. Chester                       46   9  7  7  38:35    2  2 19  23:69    61:104 -43   42
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

