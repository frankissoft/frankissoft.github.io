

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Ipswich Town                  42  17  2  2  58:28    7  6  8  35:39    93:67  +26   80
 2. Burnley                       42  14  4  3  57:26    7  7  7  44:41   101:67  +34   74
 3. Tottenham Hotspur             42  14  4  3  59:34    7  6  8  29:35    88:69  +19   73
 4. Everton                       42  17  2  2  64:21    3  9  9  24:33    88:54  +34   71
 5. Sheffield Wednesday           42  14  4  3  47:23    6  2 13  25:35    72:58  +14   66
 6. Sheffield United              42  13  5  3  37:23    6  4 11  24:46    61:69   -8   66
 7. Aston Villa                   42  13  5  3  45:20    5  3 13  20:36    65:56   +9   62
 8. West Ham United               42  11  6  4  49:37    6  4 11  27:45    76:82   -6   61
 9. Arsenal                       42   9  6  6  39:31    7  5  9  32:41    71:72   -1   59
10. West Bromwich Albion          42  10  7  4  50:23    5  6 10  33:44    83:67  +16   58
11. Manchester City               42  11  3  7  46:38    6  4 11  32:43    78:81   -3   58
12. Bolton Wanderers              42  11  7  3  35:22    5  3 13  27:44    62:66   -4   58
13. Leicester City                42  12  2  7  38:27    5  4 12  34:44    72:71   +1   57
14. Blackpool                     42  10  4  7  41:30    5  7  9  29:45    70:75   -5   56
15. Manchester United             42  10  3  8  44:31    5  6 10  28:44    72:75   -3   54
16. Blackburn Rovers              42  10  6  5  33:22    4  5 12  17:36    50:58   -8   53
17. Birmingham City               42   9  6  6  37:35    5  4 12  28:46    65:81  -16   52
18. Wolverhampton Wanderers       42   8  7  6  38:34    5  3 13  35:52    73:86  -13   49
19. Nottingham Forest             42  12  4  5  39:23    1  6 14  24:56    63:79  -16   49
20. Fulham                        42   8  3 10  38:34    5  4 12  28:40    66:74   -8   46
21. Cardiff City                  42   6  9  6  30:33    3  5 13  20:48    50:81  -31   41
22. Chelsea                       42   7  7  7  34:29    2  3 16  29:65    63:94  -31   37
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  18  3  0  68:19    9  5  7  31:24    99:43  +56   89
 2. Leyton Orient                 42  11  5  5  34:17   11  5  5  35:23    69:40  +29   76
 3. Sunderland                    42  17  3  1  60:16    5  6 10  25:34    85:50  +35   75
 4. Scunthorpe United             42  14  4  3  52:26    7  3 11  34:45    86:71  +15   70
 5. Plymouth Argyle               42  12  4  5  45:30    7  4 10  30:45    75:75        65
 6. Southampton                   42  13  3  5  53:28    5  6 10  24:34    77:62  +15   63
 7. Huddersfield Town             42  11  5  5  39:22    5  7  9  28:37    67:59   +8   60
 8. Stoke City                    42  13  4  4  34:17    4  4 13  21:40    55:57   -2   59
 9. Rotherham United              42   9  6  6  36:30    7  3 11  34:46    70:76   -6   57
10. Luton Town                    42  12  1  8  44:37    5  4 12  25:34    69:71   -2   56
11. Bury                          42   9  4  8  32:36    8  1 12  20:40    52:76  -24   56
12. Middlesbrough                 42  11  3  7  45:29    5  4 12  31:43    76:72   +4   55
13. Preston North End             42  11  4  6  34:23    4  6 11  21:34    55:57   -2   55
14. Newcastle United              42  10  5  6  40:27    5  4 12  24:31    64:58   +6   54
15. Charlton Athletic             42  10  5  6  38:30    5  4 12  31:45    69:75   -6   54
16. Walsall                       42  11  7  3  42:23    3  4 14  28:52    70:75   -5   53
17. Derby County                  42  10  7  4  42:27    4  4 13  26:48    68:75   -7   53
18. Norwich City                  42  10  6  5  36:28    4  5 12  25:42    61:70   -9   53
19. Leeds United                  42   9  6  6  24:19    3  6 12  26:42    50:61  -11   48
20. Swansea City                  42  10  5  6  38:30    2  7 12  23:53    61:83  -22   48
21. Bristol Rovers                42  11  3  7  36:31    2  4 15  17:50    53:81  -28   46
22. Brighton & Hove Albion        42   7  7  7  24:32    3  4 14  18:54    42:86  -44   41
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Portsmouth                    46  15  6  2  48:23   12  5  6  39:24    87:47  +40   92
 2. Grimsby Town                  46  18  3  2  49:18   10  3 10  31:38    80:56  +24   90
 3. Peterborough United           46  16  0  7  60:38   10  6  7  47:44   107:82  +25   84
 4. Queens Park Rangers           46  15  3  5  65:31    9  8  6  46:42   111:73  +38   83
 5. AFC Bournemouth               46  14  8  1  42:18    7  9  7  27:27    69:45  +24   80
 6. Bristol City                  46  15  3  5  56:27    8  5 10  38:45    94:72  +22   77
 7. Reading                       46  14  5  4  46:24    8  4 11  31:42    77:66  +11   75
 8. Northampton Town              46  12  6  5  52:24    8  5 10  33:33    85:57  +28   71
 9. Hull City                     46  15  2  6  43:20    5  6 12  24:34    67:54  +13   68
10. Bradford Park Avenue          46  13  5  5  47:27    7  2 14  33:51    80:78   +2   67
11. Swindon Town                  46  11  8  4  48:26    6  7 10  30:45    78:71   +7   66
12. Port Vale                     46  12  4  7  41:23    5  7 11  24:35    65:58   +7   62
13. Notts County                  46  14  5  4  44:23    3  4 16  23:51    67:74   -7   60
14. Coventry City                 46  11  6  6  38:26    5  5 13  26:45    64:71   -7   59
15. Crystal Palace                46   8  8  7  50:41    6  6 11  33:39    83:80   +3   56
16. Watford                       46  10  9  4  37:26    4  4 15  26:48    63:74  -11   55
17. Southend United               46  10  7  6  31:26    3  9 11  26:43    57:69  -12   55
18. Halifax Town                  46   9  5  9  34:35    6  5 12  28:49    62:84  -22   55
19. Shrewsbury Town               46   8  7  8  46:37    5  5 13  27:47    73:84  -11   51
20. Torquay United                46   9  4 10  48:44    6  2 15  28:56    76:100 -24   51
21. Barnsley                      46   9  6  8  45:41    4  6 13  26:54    71:95  -24   51
22. Brentford                     46  11  3  9  34:29    2  5 16  19:64    53:93  -40   47
23. Lincoln City                  46   4 10  9  31:43    5  7 11  26:44    57:87  -30   44
24. Newport County                46   6  5 12  29:38    1  3 19  17:64    46:102 -56   29
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Colchester United             46  18  4  1  81:26    7  5 11  30:47   111:73  +38   84
 2. Millwall                      45  16  3  3  47:18    8  7  8  42:44    89:62  +27   82
 3. Wrexham                       45  12  6  4  56:23   11  3  9  42:33    98:56  +42   78
 4. Carlisle United               46  16  3  4  37:22    7  5 11  29:42    66:64   +2   77
 5. Aldershot                     46  16  5  2  58:22    7  1 15  27:40    85:62  +23   75
 6. Bradford City                 46  14  5  4  58:33    8  4 11  38:54    96:87   +9   75
 7. York City                     45  18  2  3  63:19    3  8 11  22:34    85:53  +32   73
 8. Workington                    45  12  6  4  40:23    8  5 10  33:47    73:70   +3   71
 9. Rochdale                      46  15  3  5  48:28    6  4 13  26:43    74:71   +3   70
10. Barrow                        46  13  7  3  52:21    5  8 10  27:40    79:61  +18   69
11. Crewe Alexandra               46  17  3  3  57:24    4  3 16  26:47    83:71  +12   69
12. Tranmere Rovers               46  16  2  5  55:37    5  3 15  18:45    73:82   -9   68
13. Oldham Athletic               46  13  7  3  52:26    5  5 13  30:45    82:71  +11   66
14. Stockport County              46  14  3  6  44:27    5  6 12  30:43    74:70   +4   66
15. Mansfield Town                45  14  3  5  51:19    5  4 14  26:47    77:66  +11   64
16. Darlington                    46  13  6  4  38:25    5  4 14  25:52    63:77  -14   64
17. Southport                     44  13  5  4  36:25    4  4 14  25:46    61:71  -10   60
18. Exeter City                   45  12  5  6  46:32    2  6 14  19:45    65:77  -12   53
19. Gillingham                    45  11  6  6  53:31    3  5 14  25:64    78:95  -17   53
20. Chesterfield                  45  11  3  8  43:38    3  7 13  27:49    70:87  -17   52
21. Doncaster Rovers              45   8  6  9  35:30    3  2 17  26:56    61:86  -25   41
22. Chester                       46   5 10  8  36:37    3  3 17  19:59    55:96  -41   37
23. Hartlepool United             44   6  5 11  27:35    2  6 14  25:66    52:101 -49   35
24. Accrington Stanley            33   4  4  9  10:25    1  4 11   9:35    19:60  -41   23
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

