

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             42  17  4  0  51:13    7  8  6  33:32    84:45  +39   84
 2. Tottenham Hotspur             42  15  3  3  44:21    9  5  7  27:27    71:48  +23   80
 3. Nottingham Forest             42  16  4  1  41:13    7  6  8  23:28    64:41  +23   79
 4. Leeds United                  42  15  4  2  41:17    7  7  7  21:25    62:42  +20   77
 5. Liverpool                     42  12  7  2  36:17    7  6  8  28:30    64:47  +17   70
 6. Everton                       42  11  4  6  39:22    8  6  7  26:24    65:46  +19   67
 7. Arsenal                       42  11  6  4  32:20    5  8  8  26:27    58:47  +11   62
 8. Leicester City                42  12  4  5  47:28    6  4 11  31:43    78:71   +7   62
 9. Chelsea                       42   7  9  5  33:29    8  5  8  34:33    67:62   +5   59
10. Stoke City                    42  11  5  5  40:21    6  2 13  23:37    63:58   +5   58
11. Sheffield United              42  11  5  5  34:22    5  5 11  18:37    52:59   -7   58
12. Sheffield Wednesday           42   9  7  5  39:19    5  6 10  17:28    56:47   +9   55
13. West Bromwich Albion          42  11  1  9  40:28    5  6 10  37:45    77:73   +4   55
14. Burnley                       42  11  4  6  43:28    4  5 12  23:48    66:76  -10   54
15. Manchester City               42   8  9  4  27:25    4  6 11  16:27    43:52   -9   51
16. West Ham United               42   8  6  7  40:31    6  2 13  40:53    80:84   -4   50
17. Sunderland                    42  12  3  6  39:26    2  5 14  19:46    58:72  -14   50
18. Southampton                   42  10  3  8  49:41    4  3 14  25:51    74:92  -18   48
19. Fulham                        42   8  7  6  49:34    3  5 13  22:49    71:83  -12   45
20. Newcastle United              42   9  5  7  24:27    3  4 14  15:54    39:81  -42   45
21. Aston Villa                   42   7  5  9  30:33    4  2 15  24:52    54:85  -31   40
22. Blackpool                     42   1  5 15  18:36    5  4 12  23:40    41:76  -35   27
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wolverhampton Wanderers       42  15  4  2  53:20   10  4  7  35:28    88:48  +40   83
 2. Coventry City                 42  17  3  1  46:16    6 10  5  28:27    74:43  +31   82
 3. Carlisle United               42  15  3  3  42:16    8  3 10  29:38    71:54  +17   75
 4. Blackburn Rovers              42  13  6  2  33:11    6  7  8  23:35    56:46  +10   70
 5. Huddersfield Town             42  14  3  4  36:17    6  6  9  22:29    58:46  +12   69
 6. Ipswich Town                  42  11  8  2  45:25    6  8  7  25:29    70:54  +16   67
 7. Crystal Palace                42  14  4  3  42:23    5  6 10  19:32    61:55   +6   67
 8. Millwall                      42  14  5  2  33:17    4  4 13  16:41    49:58   -9   63
 9. Bolton Wanderers              42  10  7  4  36:19    4  7 10  28:39    64:58   +6   56
10. Birmingham City               42  11  5  5  42:23    5  3 13  28:43    70:66   +4   56
11. Hull City                     42  11  5  5  46:25    5  2 14  31:47    77:72   +5   55
12. Preston North End             42  14  3  4  44:23    2  4 15  21:44    65:67   -2   55
13. Norwich City                  42  10  7  4  31:21    3  7 11  18:34    49:55   -6   53
14. Portsmouth                    42   7  5  9  34:37    6  8  7  25:33    59:70  -11   52
15. Plymouth Argyle               42  12  4  5  42:21    2  5 14  17:37    59:58   +1   51
16. Bristol City                  42  10  8  3  38:22    2  6 13  18:40    56:62   -6   50
17. Rotherham United              42  10  5  6  39:28    3  5 13  22:42    61:70   -9   49
18. Derby County                  42   8  6  7  40:32    4  6 11  28:40    68:72   -4   48
19. Charlton Athletic             42  11  4  6  34:16    2  5 14  15:37    49:53   -4   48
20. Cardiff City                  42   9  7  5  43:28    3  2 16  18:59    61:87  -26   45
21. Northampton Town              42   8  6  7  28:33    4  0 17  19:51    47:84  -37   42
22. Bury                          42   9  3  9  31:30    2  3 16  18:53    49:83  -34   39
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Queens Park Rangers           46  18  4  1  66:15    8 11  4  37:23   103:38  +65   93
 2. Middlesbrough                 46  16  3  4  51:20    7  6 10  36:44    87:64  +23   78
 3. Reading                       46  13  7  3  45:20    9  2 12  31:37    76:57  +19   75
 4. Watford                       46  15  5  3  39:17    5  9  9  22:29    61:46  +15   74
 5. Bristol Rovers                46  13  8  2  47:28    7  5 11  29:39    76:67   +9   73
 6. Torquay United                46  17  3  3  57:20    4  6 13  16:34    73:54  +19   72
 7. Shrewsbury Town               46  15  5  3  48:24    5  7 11  29:38    77:62  +15   72
 8. Swindon Town                  46  14  5  4  53:21    6  5 12  28:38    81:59  +22   70
 9. Mansfield Town                46  12  4  7  48:37    8  5 10  36:42    84:79   +5   69
10. Oldham Athletic               46  15  4  4  51:16    4  6 13  29:47    80:63  +17   67
11. Walsall                       46  12  8  3  37:16    6  2 15  28:56    65:72   -7   64
12. Colchester United             46  14  3  6  52:30    3  7 13  24:43    76:73   +3   61
13. Gillingham                    46  11  9  3  36:18    4  7 12  22:44    58:62   -4   61
14. Grimsby Town                  46  13  5  5  46:23    4  4 15  15:45    61:68   -7   60
15. Scunthorpe United             46  13  4  6  39:26    4  4 15  19:47    58:73  -15   59
16. Oxford United                 46  10  8  5  41:29    5  5 13  20:37    61:66   -5   58
17. Peterborough United           46  12  4  7  40:31    2 11 10  26:40    66:71   -5   57
18. Leyton Orient                 46  10  9  4  36:27    3  9 11  22:41    58:68  -10   57
19. Brighton & Hove Albion        46  10  8  5  37:27    3  7 13  24:44    61:71  -10   54
20. AFC Bournemouth               46   8 10  5  24:24    4  7 12  15:33    39:57  -18   53
21. Swansea City                  46   9  9  5  50:30    3  6 14  35:59    85:89   -4   51
22. Darlington                    46   8  7  8  26:28    5  4 14  21:53    47:81  -34   50
23. Doncaster Rovers              46  11  6  6  40:40    1  2 20  18:77    58:117 -59   44
24. Workington                    46   9  3 11  35:35    3  4 16  20:54    55:89  -34   43
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Stockport County              46  16  5  2  41:18   10  7  6  28:24    69:42  +27   90
 2. Barrow                        46  12  8  3  35:18   12  3  8  41:36    76:54  +22   83
 3. Southport                     46  19  2  2  47:15    4 11  8  22:27    69:42  +27   82
 4. Tranmere Rovers               46  14  6  3  42:20    8  8  7  24:23    66:43  +23   80
 5. Southend United               46  15  5  3  44:12    7  4 12  26:37    70:49  +21   75
 6. Crewe Alexandra               46  14  5  4  42:26    7  7  9  28:29    70:55  +15   75
 7. Hartlepool United             46  15  3  5  44:29    7  4 12  22:35    66:64   +2   73
 8. Wrexham                       46  11 12  0  46:20    5  8 10  30:42    76:62  +14   68
 9. Bradford City                 46  13  4  6  48:31    6  6 11  26:31    74:62  +12   67
10. Brentford                     46  13  7  3  36:19    5  6 12  22:37    58:56   +2   67
11. Aldershot                     46  14  4  5  48:19    4  8 11  24:38    72:57  +15   66
12. Chesterfield                  46  13  6  4  33:16    4  2 17  27:47    60:63   -3   59
13. Halifax Town                  46  10 11  2  37:27    5  3 15  22:41    59:68   -9   59
14. Port Vale                     46   9  7  7  33:27    5  8 10  22:31    55:58   -3   57
15. Exeter City                   46  11  6  6  30:24    3  9 11  20:36    50:60  -10   57
16. Luton Town                    46  15  5  3  47:23    1  4 18  12:50    59:73  -14   57
17. Chester                       46   8  5 10  24:32    7  5 11  30:46    54:78  -24   55
18. Barnsley                      46   8  7  8  30:28    5  8 10  30:36    60:64   -4   54
19. Newport County                46   9  9  5  35:23    3  7 13  21:40    56:63   -7   52
20. Notts County                  46  10  7  6  31:25    3  4 16  22:47    53:72  -19   50
21. Rochdale                      46  10  4  9  30:27    3  7 13  23:48    53:75  -22   50
22. York City                     46  11  5  7  45:31    1  6 16  20:48    65:79  -14   47
23. Bradford Park Avenue          46   7  6 10  30:34    4  7 12  22:45    52:79  -27   46
24. Lincoln City                  46   7  8  8  39:39    2  5 16  19:43    58:82  -24   40
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

