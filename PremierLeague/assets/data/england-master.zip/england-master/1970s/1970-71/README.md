

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       42  18  3  0  41:6    11  4  6  30:23    71:29  +42   94
 2. Leeds United                  42  16  2  3  40:12   11  8  2  32:18    72:30  +42   91
 3. Wolverhampton Wanderers       42  13  3  5  33:22    9  5  7  31:32    64:54  +10   74
 4. Tottenham Hotspur             42  11  5  5  33:19    8  9  4  21:14    54:33  +21   71
 5. Chelsea                       42  12  6  3  34:21    6  9  6  18:21    52:42  +10   69
 6. Liverpool                     42  11 10  0  30:10    6  7  8  12:14    42:24  +18   68
 7. Southampton                   42  12  5  4  35:15    5  7  9  21:29    56:44  +12   63
 8. Manchester United             42   9  6  6  29:24    7  5  9  36:42    65:66   -1   59
 9. Derby County                  42   9  5  7  32:26    7  5  9  24:28    56:54   +2   58
10. Coventry City                 42  12  4  5  24:12    4  6 11  13:26    37:38   -1   58
11. Newcastle United              42   9  9  3  27:16    5  4 12  17:30    44:46   -2   55
12. Manchester City               42   7  9  5  30:22    5  8  8  17:20    47:42   +5   53
13. Nottingham Forest             42   9  4  8  29:26    5  4 12  13:35    42:61  -19   50
14. Stoke City                    42  10  7  4  28:11    2  6 13  16:37    44:48   -4   49
15. Everton                       42  10  7  4  32:16    2  6 13  22:44    54:60   -6   49
16. Huddersfield Town             42   7  8  6  19:16    4  6 11  21:33    40:49   -9   47
17. Crystal Palace                42   9  5  7  24:24    3  6 12  15:33    39:57  -18   47
18. Ipswich Town                  42   9  4  8  28:22    3  6 12  14:26    42:48   -6   46
19. West Bromwich Albion          42   9  8  4  34:25    1  7 13  24:50    58:75  -17   45
20. West Ham United               42   6  8  7  28:30    4  6 11  19:30    47:60  -13   44
21. Burnley                       42   4  8  9  20:31    3  5 13   9:32    29:63  -34   34
22. Blackpool                     42   3  9  9  22:31    1  6 14  12:35    34:66  -32   27
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leicester City                42  12  7  2  30:14   11  6  4  27:16    57:30  +27   82
 2. Sheffield United              42  14  6  1  49:18    7  8  6  24:21    73:39  +34   77
 3. Cardiff City                  42  12  7  2  39:16    8  6  7  25:25    64:41  +23   73
 4. Carlisle United               42  16  3  2  39:13    4 10  7  26:30    65:43  +22   73
 5. Hull City                     42  11  5  5  31:16    8  8  5  23:25    54:41  +13   70
 6. Luton Town                    42  12  7  2  40:18    6  6  9  22:25    62:43  +19   67
 7. Millwall                      42  13  5  3  36:12    6  4 11  23:30    59:42  +17   66
 8. Middlesbrough                 42  13  6  2  37:16    4  8  9  21:27    58:43  +15   65
 9. Birmingham City               42  12  7  2  30:12    5  5 11  28:36    58:48  +10   63
10. Queens Park Rangers           42  11  5  5  39:22    5  6 10  19:31    58:53   +5   59
11. Norwich City                  42  11  8  2  34:20    4  6 11  19:32    53:52   +1   59
12. Swindon Town                  42  12  7  2  38:14    3  5 13  23:37    61:51  +10   57
13. Sunderland                    42  11  6  4  34:21    4  6 11  18:33    52:54   -2   57
14. Oxford United                 42   8  8  5  23:23    6  6  9  18:25    41:48   -7   56
15. Sheffield Wednesday           42  10  7  4  32:24    2  5 14  19:42    51:66  -15   48
16. Portsmouth                    42   9  4  8  32:28    1 10 10  14:33    46:61  -15   44
17. Watford                       42   6  7  8  18:22    4  6 11  20:38    38:60  -22   43
18. Leyton Orient                 42   5 11  5  16:15    4  5 12  13:36    29:51  -22   43
19. Bristol City                  42   9  6  6  30:28    1  5 15  16:36    46:64  -18   41
20. Charlton Athletic             42   7  6  8  28:30    1  8 12  13:35    41:65  -24   38
21. Blackburn Rovers              42   5  8  8  20:28    1  7 13  17:41    37:69  -32   33
22. Bolton Wanderers              42   6  5 10  22:31    1  5 15  13:43    35:74  -39   31
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Fulham                        46  15  6  2  39:12    9  6  8  29:29    68:41  +27   84
 2. Preston North End             46  15  8  0  42:16    7  9  7  21:23    63:39  +24   83
 3. Halifax Town                  46  16  2  5  46:22    6 10  7  28:33    74:55  +19   78
 4. Aston Villa                   46  13  7  3  27:13    6  8  9  27:33    54:46   +8   72
 5. Bristol Rovers                46  11  5  7  38:24    8  8  7  31:26    69:50  +19   70
 6. Mansfield Town                46  13  7  3  44:28    5  8 10  19:34    63:62   +1   69
 7. Chesterfield                  46  13  8  2  45:12    4  9 10  21:26    66:38  +28   68
 8. Torquay United                46  12  6  5  37:26    7  5 11  17:31    54:57   -3   68
 9. Wrexham                       46  12  8  3  43:25    6  5 12  29:40    72:65   +7   67
10. Rotherham United              46  12 10  1  38:19    5  6 12  26:41    64:60   +4   67
11. Barnsley                      46  12  6  5  30:19    5  5 13  19:33    49:52   -3   62
12. Swansea City                  46  11  5  7  41:25    4 11  8  18:31    59:56   +3   61
13. Shrewsbury Town               46  11  6  6  37:27    5  7 11  21:34    58:61   -3   61
14. Brighton & Hove Albion        46   8 10  5  28:20    6  6 11  22:27    50:47   +3   58
15. Rochdale                      46   8  8  7  29:26    6  7 10  32:42    61:68   -7   57
16. Port Vale                     46  11  6  6  29:18    4  6 13  23:41    52:59   -7   57
17. Plymouth Argyle               46   6 12  5  39:33    6  7 10  24:30    63:63        55
18. Walsall                       46  10  1 12  30:27    4 10  9  21:30    51:57   -6   53
19. Bradford City                 46   7  6 10  23:25    6  8  9  26:37    49:62  -13   53
20. Reading                       46  10  7  6  32:33    4  4 15  16:52    48:85  -37   53
21. Tranmere Rovers               46   8 11  4  27:18    2 11 10  18:37    45:55  -10   52
22. Bury                          46   7  9  7  30:23    5  4 14  22:37    52:60   -8   49
23. Doncaster Rovers              46   8  5 10  28:27    5  4 14  17:39    45:66  -21   48
24. Gillingham                    46   6  9  8  22:29    4  4 15  20:38    42:67  -25   43
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Notts County                  46  19  4  0  59:12   11  5  7  30:24    89:36  +53   99
 2. AFC Bournemouth               46  16  5  2  51:15    8  7  8  30:31    81:46  +35   84
 3. Oldham Athletic               46  14  6  3  57:29   10  5  8  31:34    88:63  +25   83
 4. York City                     46  16  6  1  45:14    7  4 12  33:40    78:54  +24   79
 5. Chester                       46  17  2  4  42:18    7  5 11  27:37    69:55  +14   79
 6. Colchester United             46  14  6  3  44:19    7  6 10  26:35    70:54  +16   75
 7. Northampton Town              46  15  4  4  39:24    4  9 10  24:35    63:59   +4   70
 8. Southport                     46  15  2  6  42:24    6  4 13  21:33    63:57   +6   69
 9. Workington                    46  13  7  3  28:13    5  5 13  20:36    48:49   -1   66
10. Exeter City                   46  12  7  4  40:23    5  7 11  27:45    67:68   -1   65
11. Brentford                     46  13  3  7  45:27    5  5 13  21:35    66:62   +4   62
12. Darlington                    46  15  3  5  42:22    2  8 13  16:35    58:57   +1   62
13. Crewe Alexandra               46  13  1  9  49:35    5  7 11  26:41    75:76   -1   62
14. Stockport County              46  12  8  3  28:17    4  6 13  21:48    49:65  -16   62
15. Peterborough United           46  14  3  6  46:23    4  4 15  24:48    70:71   -1   61
16. Grimsby Town                  46  13  4  6  37:26    5  3 15  20:45    57:71  -14   61
17. Aldershot                     46   8 10  5  32:23    6  7 10  34:48    66:71   -5   59
18. Scunthorpe United             46   9  7  7  36:23    6  6 11  20:38    56:61   -5   58
19. Cambridge United              46   9  9  5  31:27    6  4 13  20:39    51:66  -15   58
20. Southend United               46   8 11  4  32:24    6  4 13  21:42    53:66  -13   57
21. Lincoln City                  46  11  4  8  45:33    2  9 12  25:38    70:71   -1   52
22. Newport County                46   8  3 12  32:36    2  5 16  23:49    55:85  -30   38
23. Hartlepool United             46   6 10  7  28:27    2  2 19   6:47    34:74  -40   36
24. Barrow                        46   5  5 13  25:38    2  3 18  26:52    51:90  -39   29
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

