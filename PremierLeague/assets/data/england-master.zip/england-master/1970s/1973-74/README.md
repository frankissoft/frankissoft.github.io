

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leeds United                  42  12  8  1  38:18   12  6  3  28:13    66:31  +35   86
 2. Liverpool                     42  18  2  1  34:11    4 11  6  18:20    52:31  +21   79
 3. Derby County                  42  13  7  1  40:16    4  7 10  12:26    52:42  +10   65
 4. Ipswich Town                  42  10  7  4  38:21    8  4  9  29:37    67:58   +9   65
 5. Burnley                       42  10  9  2  29:16    6  5 10  27:37    56:53   +3   62
 6. Stoke City                    42  13  6  2  39:15    2 10  9  15:27    54:42  +12   61
 7. Everton                       42  12  7  2  29:14    4  5 12  21:34    50:48   +2   60
 8. Queens Park Rangers           42   8 10  3  30:17    5  7  9  26:35    56:52   +4   56
 9. Arsenal                       42   9  7  5  23:16    5  7  9  26:35    49:51   -2   56
10. Tottenham Hotspur             42   9  4  8  26:27    5 10  6  19:23    45:50   -5   56
11. Leicester City                42  10  7  4  35:17    3  9  9  16:24    51:41  +10   55
12. Wolverhampton Wanderers       42  11  6  4  30:18    2  9 10  19:31    49:49        54
13. Sheffield United              42   7  7  7  25:22    7  5  9  19:27    44:49   -5   54
14. Manchester City               42  10  7  4  25:17    4  5 12  14:29    39:46   -7   54
15. Coventry City                 42  10  5  6  25:18    4  5 12  18:36    43:54  -11   52
16. Newcastle United              42   9  6  6  28:21    4  6 11  21:27    49:48   +1   51
17. Chelsea                       42   9  4  8  36:29    3  9  9  20:31    56:60   -4   49
18. Birmingham City               42  10  7  4  30:21    2  6 13  22:43    52:64  -12   49
19. West Ham United               42   7  7  7  36:32    4  8  9  19:28    55:60   -5   48
20. Southampton                   42   8 10  3  30:20    3  4 14  17:48    47:68  -21   47
21. Manchester United             42   7  7  7  23:20    3  5 13  15:28    38:48  -10   42
22. Norwich City                  42   6  9  6  25:27    1  6 14  12:35    37:62  -25   36
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Middlesbrough                 42  16  4  1  40:8    11  7  3  37:22    77:30  +47   92
 2. Luton Town                    42  12  5  4  42:25    7  7  7  22:26    64:51  +13   69
 3. Carlisle United               42  13  5  3  40:17    7  4 10  21:31    61:48  +13   69
 4. Sunderland                    42  11  6  4  32:15    8  3 10  26:29    58:44  +14   66
 5. Blackpool                     42  11  5  5  35:17    6  8  7  22:23    57:40  +17   64
 6. Leyton Orient                 42   9  8  4  28:17    6 10  5  27:25    55:42  +13   63
 7. Nottingham Forest             42  12  6  3  40:19    3  9  9  17:24    57:43  +14   60
 8. West Bromwich Albion          42   8  9  4  28:24    6  7  8  20:21    48:45   +3   58
 9. Fulham                        42  11  4  6  26:20    5  6 10  13:23    39:43   -4   58
10. Notts County                  42   8  6  7  30:35    7  7  7  25:25    55:60   -5   58
11. Bolton Wanderers              42  12  5  4  30:17    3  7 11  14:23    44:40   +4   57
12. Millwall                      42  10  6  5  28:16    4  8  9  23:35    51:51        56
13. Hull City                     42   9  9  3  25:15    4  8  9  21:32    46:47   -1   56
14. Aston Villa                   42   8  9  4  33:21    5  6 10  15:24    48:45   +3   54
15. Portsmouth                    42   9  8  4  26:16    5  4 12  19:46    45:62  -17   54
16. Bristol City                  42   9  5  7  25:20    5  5 11  22:34    47:54   -7   52
17. Sheffield Wednesday           42   9  6  6  33:24    3  5 13  18:39    51:63  -12   47
18. Oxford United                 42   8  8  5  27:21    2  8 11   8:25    35:46  -11   46
19. Cardiff City                  42   8  7  6  27:20    2  9 10  22:42    49:62  -13   46
20. Crystal Palace                42   6  7  8  24:24    5  5 11  19:32    43:56  -13   45
21. Preston North End             42   7  8  6  24:23    2  6 13  16:39    40:62  -22   41
22. Swindon Town                  42   6  7  8  22:27    1  4 16  14:45    36:72  -36   32
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Oldham Athletic               46  13  6  4  50:23   12  6  5  33:24    83:47  +36   87
 2. Bristol Rovers                46  15  6  2  37:15    7 11  5  28:18    65:33  +32   83
 3. York City                     46  13  8  2  37:15    8 11  4  30:23    67:38  +29   82
 4. Wrexham                       46  15  6  2  44:15    7  6 10  19:28    63:43  +20   78
 5. Chesterfield                  46  14  6  3  31:16    7  8  8  24:26    55:42  +13   77
 6. Grimsby Town                  46  14  6  3  48:21    4  9 10  19:29    67:50  +17   69
 7. Watford                       46  12  6  5  34:21    7  6 10  30:35    64:56   +8   69
 8. Aldershot                     46  13  6  4  47:22    6  5 12  18:30    65:52  +13   68
 9. Charlton Athletic             46  13  5  5  43:29    6  3 14  23:44    66:73   -7   65
10. Huddersfield Town             46  14  5  4  37:16    3  8 12  19:39    56:55   +1   64
11. Blackburn Rovers              46  13  4  6  38:21    5  6 12  24:43    62:64   -2   64
12. Halifax Town                  46   9 11  3  23:15    5 10  8  25:36    48:51   -3   63
13. AFC Bournemouth               46  11  5  7  25:23    5 10  8  29:35    54:58   -4   63
14. Southend United               46  10  7  6  40:30    6  7 10  22:32    62:62        62
15. Walsall                       46  11  7  5  37:19    5  6 12  20:29    57:48   +9   61
16. Plymouth Argyle               46  13  6  4  37:17    4  4 15  22:37    59:54   +5   61
17. Tranmere Rovers               46  10  8  5  31:15    5  7 11  19:29    50:44   +6   60
18. Brighton & Hove Albion        46  10  3 10  31:31    6  8  9  21:27    52:58   -6   59
19. Hereford United               46  10  5  8  31:25    4 10  9  22:32    53:57   -4   57
20. Port Vale                     46  12  6  5  37:23    2  8 13  15:35    52:58   -6   56
21. Cambridge United              46  11  7  5  36:27    2  2 19  12:54    48:81  -33   48
22. Shrewsbury Town               46   7  7  9  24:24    3  4 16  17:38    41:62  -21   41
23. Southport                     46   4 14  5  19:20    2  2 19  16:62    35:82  -47   34
24. Rochdale                      46   1 12 10  24:38    1  5 17  14:56    38:94  -56   23
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Peterborough United           46  19  4  0  49:10    8  7  8  26:28    75:38  +37   92
 2. Gillingham                    46  16  5  2  51:16    9  7  7  39:33    90:49  +41   87
 3. Colchester United             46  16  5  2  46:14    8  7  8  27:22    73:36  +37   84
 4. Bury                          46  18  3  2  51:14    6  8  9  30:35    81:49  +32   83
 5. Northampton Town              46  14  7  2  39:14    6  6 11  24:34    63:48  +15   73
 6. Reading                       46  11  9  3  37:13    5 10  8  21:24    58:37  +21   67
 7. Chester                       46  13  6  4  31:19    4  9 10  23:36    54:55   -1   66
 8. Bradford City                 46  14  7  2  45:20    3  7 13  13:32    58:52   +6   65
 9. Exeter City                   45  12  5  6  37:20    6  3 13  21:35    58:55   +3   62
10. Newport County                46  13  6  4  39:23    3  8 12  17:42    56:65   -9   62
11. Barnsley                      46  15  5  3  42:16    2  5 16  16:48    58:64   -6   61
12. Hartlepool United             46  11  4  8  29:16    5  8 10  19:31    48:47   +1   60
13. Lincoln City                  46  10  8  5  40:30    6  4 13  23:37    63:67   -4   60
14. Swansea City                  46  11  6  6  28:15    5  5 13  17:31    45:46   -1   59
15. Rotherham United              46  10  9  4  33:22    5  4 14  23:36    56:58   -2   58
16. Torquay United                46  11  7  5  37:23    2 10 11  15:34    52:57   -5   56
17. Mansfield Town                46  13  8  2  47:24    0  9 14  15:45    62:69   -7   56
18. Scunthorpe United             45  12  7  3  33:17    2  5 16  14:47    47:64  -17   54
19. Brentford                     46   9  7  7  31:20    3  9 11  17:30    48:50   -2   52
20. Darlington                    46   9  8  6  29:24    4  5 14  11:38    40:62  -22   52
21. Crewe Alexandra               46  11  5  7  28:30    3  5 15  15:41    43:71  -28   52
22. Doncaster Rovers              46  10  7  6  32:22    2  4 17  15:58    47:80  -33   47
23. Workington                    46  10  8  5  33:26    1  5 17  10:48    43:74  -31   46
24. Stockport County              46   4 12  7  22:25    3  8 12  22:44    44:69  -25   41
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

