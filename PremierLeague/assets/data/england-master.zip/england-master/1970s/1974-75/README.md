

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Ipswich Town                  42  17  2  2  47:14    6  3 12  19:30    66:44  +22   74
 2. Derby County                  42  14  4  3  41:18    7  7  7  26:31    67:49  +18   74
 3. Liverpool                     42  14  5  2  44:17    6  6  9  16:22    60:39  +21   71
 4. Sheffield United              42  12  7  2  35:20    6  6  9  23:31    58:51   +7   67
 5. Stoke City                    42  12  7  2  40:18    5  8  8  24:30    64:48  +16   66
 6. Everton                       42  10  9  2  33:19    6  9  6  23:23    56:42  +14   66
 7. Middlesbrough                 42  11  7  3  33:14    7  5  9  21:26    54:40  +14   66
 8. Manchester City               42  16  3  2  40:15    2  7 12  14:39    54:54        64
 9. Burnley                       42  11  6  4  40:29    6  5 10  28:38    68:67   +1   62
10. Leeds United                  42  10  8  3  34:20    6  5 10  23:29    57:49   +8   61
11. Queens Park Rangers           42  10  4  7  25:17    6  6  9  29:37    54:54        58
12. Newcastle United              42  12  4  5  39:23    3  5 13  20:49    59:72  -13   54
13. Wolverhampton Wanderers       42  12  5  4  43:21    2  6 13  14:33    57:54   +3   53
14. West Ham United               42  10  6  5  38:22    3  7 11  20:37    58:59   -1   52
15. Birmingham City               42  10  4  7  34:28    4  5 12  19:33    53:61   -8   51
16. Coventry City                 42   8  9  4  31:27    4  6 11  20:35    51:62  -11   51
17. Arsenal                       42  10  6  5  31:16    3  5 13  16:33    47:49   -2   50
18. Leicester City                42   8  7  6  25:17    4  5 12  21:43    46:60  -14   48
19. Tottenham Hotspur             42   8  4  9  29:27    5  4 12  23:36    52:63  -11   47
20. Luton Town                    42   8  6  7  27:26    3  5 13  20:39    47:65  -18   44
21. Chelsea                       42   4  9  8  22:31    5  6 10  20:41    42:72  -30   42
22. Carlisle United               42   8  2 11  22:21    4  3 14  21:38    43:59  -16   41
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             42  17  3  1  45:12    9  6  6  21:18    66:30  +36   87
 2. Aston Villa                   42  16  4  1  47:6     9  4  8  32:26    79:32  +47   83
 3. Norwich City                  42  14  3  4  34:17    6 10  5  24:20    58:37  +21   73
 4. Bristol City                  42  14  5  2  31:10    7  3 11  16:23    47:33  +14   71
 5. Sunderland                    42  14  6  1  41:8     5  7  9  24:27    65:35  +30   70
 6. West Bromwich Albion          42  13  4  4  33:15    5  5 11  21:27    54:42  +12   63
 7. Blackpool                     42  12  6  3  31:17    2 11  8   7:16    38:33   +5   59
 8. Hull City                     42  12  8  1  25:10    3  6 12  15:43    40:53  -13   59
 9. Bolton Wanderers              42   9  7  5  27:16    6  5 10  18:25    45:41   +4   57
10. Oxford United                 42  14  3  4  30:19    1  9 11  11:32    41:51  -10   57
11. Southampton                   42  10  6  5  29:20    5  5 11  24:34    53:54   -1   56
12. Fulham                        42   9  8  4  29:17    4  8  9  15:22    44:39   +5   55
13. Leyton Orient                 42   8  9  4  17:16    3 11  7  11:23    28:39  -11   53
14. York City                     42   9  7  5  28:18    5  3 13  23:37    51:55   -4   52
15. Notts County                  42   7 11  3  34:26    5  5 11  15:33    49:59  -10   52
16. Nottingham Forest             42   7  7  7  24:23    5  7  9  19:32    43:55  -12   50
17. Portsmouth                    42   9  7  5  28:20    3  6 12  16:34    44:54  -10   49
18. Bristol Rovers                42  10  4  7  25:23    2  7 12  17:41    42:64  -22   47
19. Oldham Athletic               42  10  7  4  28:16    0  8 13  12:32    40:48   -8   45
20. Millwall                      42   8  9  4  31:19    2  3 16  13:37    44:56  -12   42
21. Cardiff City                  42   7  8  6  24:21    2  6 13  12:41    36:62  -26   41
22. Sheffield Wednesday           42   3  7 11  17:29    2  4 15  12:35    29:64  -35   26
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Plymouth Argyle               46  16  5  2  38:19    8  6  9  41:39    79:58  +21   83
 2. Blackburn Rovers              46  15  7  1  40:16    7  9  7  28:29    68:45  +23   82
 3. Charlton Athletic             46  15  5  3  51:29    7  6 10  25:32    76:61  +15   77
 4. Swindon Town                  46  18  3  2  43:17    3  8 12  21:41    64:58   +6   74
 5. Crystal Palace                46  14  8  1  48:22    4  7 12  18:35    66:57   +9   69
 6. Port Vale                     46  15  6  2  37:19    3  9 11  24:35    61:54   +7   69
 7. Peterborough United           46  10  9  4  24:17    9  3 11  23:36    47:53   -6   69
 8. Preston North End             46  16  5  2  42:19    3  6 14  21:37    63:56   +7   68
 9. Walsall                       46  15  5  3  46:13    3  8 12  21:39    67:52  +15   67
10. Gillingham                    46  14  6  3  43:23    3  8 12  22:37    65:60   +5   65
11. Colchester United             46  13  7  3  45:22    4  6 13  25:41    70:63   +7   64
12. Hereford United               46  14  6  3  42:21    2  8 13  22:45    64:66   -2   62
13. Wrexham                       46  10  8  5  41:23    5  7 11  24:32    65:55  +10   60
14. Bury                          46  13  6  4  38:17    3  6 14  15:33    53:50   +3   60
15. Chesterfield                  46  11  7  5  37:25    5  5 13  25:41    62:66   -4   60
16. Brighton & Hove Albion        46  14  7  2  38:21    2  3 18  18:43    56:64   -8   58
17. Grimsby Town                  46  12  8  3  35:19    3  5 15  20:45    55:64   -9   58
18. Halifax Town                  46  11 10  2  33:20    2  7 14  16:45    49:65  -16   56
19. Southend United               46  11  9  3  32:17    2  7 14  14:34    46:51   -5   55
20. Aldershot                     46  13  5  5  40:21    1  6 16  13:42    53:63  -10   53
21. Tranmere Rovers               46  12  4  7  39:21    2  5 16  16:36    55:57   -2   51
22. AFC Bournemouth               46   9  6  8  27:25    4  6 13  17:33    44:58  -14   51
23. Watford                       46   9  7  7  30:31    1 10 12  22:44    52:75  -23   47
24. Huddersfield Town             46   9  6  8  32:29    2  4 17  15:47    47:76  -29   43
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Mansfield Town                46  17  6  0  55:15   11  6  6  35:25    90:40  +50   96
 2. Shrewsbury Town               46  16  3  4  46:18   10  7  6  34:25    80:43  +37   88
 3. Rotherham United              46  13  7  3  40:19    9  8  6  31:22    71:41  +30   81
 4. Chester                       46  17  5  1  48:9     6  6 11  16:29    64:38  +26   80
 5. Lincoln City                  46  14  8  1  47:14    7  7  9  32:34    79:48  +31   78
 6. Cambridge United              46  15  5  3  43:16    5  9  9  19:28    62:44  +18   74
 7. Reading                       46  13  6  4  38:20    8  4 11  25:27    63:47  +16   73
 8. Exeter City                   46  14  3  6  33:24    5  8 10  27:39    60:63   -3   68
 9. Brentford                     46  15  6  2  38:14    3  7 13  15:31    53:45   +8   67
10. Newport County                46  13  5  5  43:30    6  4 13  25:45    68:75   -7   66
11. Bradford City                 46  10  5  8  32:21    7  8  8  24:30    56:51   +5   64
12. Southport                     46  13  7  3  36:19    2 10 11  20:37    56:56        62
13. Hartlepool United             46  13  6  4  40:24    3  5 15  12:38    52:62  -10   59
14. Barnsley                      46  10  7  6  34:24    5  4 14  28:41    62:65   -3   56
15. Northampton Town              46  12  6  5  43:22    3  5 15  24:51    67:73   -6   56
16. Torquay United                46  10  7  6  30:25    4  7 12  16:36    46:61  -15   56
17. Doncaster Rovers              46  10  9  4  41:29    4  3 16  24:50    65:79  -14   54
18. Rochdale                      46   9  9  5  35:22    4  4 15  24:53    59:75  -16   52
19. Crewe Alexandra               46   9  9  5  22:16    2  9 12  12:31    34:47  -13   51
20. Swansea City                  46   9  4 10  25:31    6  2 15  21:42    46:73  -27   51
21. Stockport County              46  10  8  5  26:27    2  6 15  17:43    43:70  -27   50
22. Darlington                    46  11  4  8  38:27    2  6 15  16:40    54:67  -13   49
23. Workington                    46   7  5 11  23:29    3  6 14  13:37    36:66  -30   41
24. Scunthorpe United             46   7  8  8  27:29    0  7 16  14:49    41:78  -37   36
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

