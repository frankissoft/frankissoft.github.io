

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   42  16  3  2  40:13   10  5  6  32:27    72:40  +32   86
 2. Ipswich Town                  42  15  4  2  45:14    8  6  7  32:29    77:43  +34   79
 3. West Bromwich Albion          42  15  4  2  40:15    5  8  8  20:27    60:42  +18   72
 4. Arsenal                       42  13  8  0  36:17    6  7  8  25:28    61:45  +16   72
 5. Southampton                   42  15  4  2  47:22    5  6 10  29:34    76:56  +20   70
 6. Nottingham Forest             42  15  3  3  44:20    4  9  8  18:24    62:44  +18   69
 7. Liverpool                     42  13  5  3  38:15    4 12  5  24:27    62:42  +20   68
 8. Manchester United             42   9 11  1  30:14    6  7  8  21:22    51:36  +15   63
 9. Leeds United                  42  10  5  6  19:19    7  5  9  20:28    39:47   -8   61
10. Tottenham Hotspur             42   9  9  3  44:31    5  6 10  26:37    70:68   +2   57
11. Stoke City                    42   8  9  4  31:23    4  9  8  20:37    51:60   -9   54
12. Manchester City               42  10  7  4  35:25    4  4 13  21:34    56:59   -3   53
13. Middlesbrough                 42  14  4  3  38:16    2  1 18  15:45    53:61   -8   53
14. Birmingham City               42  11  5  5  32:23    2  7 12  18:38    50:61  -11   51
15. Sunderland                    42  10  4  7  32:19    4  3 14  20:34    52:53   -1   49
16. Everton                       42   8  6  7  32:25    5  4 12  23:33    55:58   -3   49
17. Brighton & Hove Albion        42  10  3  8  30:26    4  4 13  24:41    54:67  -13   49
18. Coventry City                 42   9  6  6  31:30    4  4 13  17:38    48:68  -20   49
19. Wolverhampton Wanderers       42  11  2  8  26:20    2  7 12  17:35    43:55  -12   48
20. Norwich City                  42   9  7  5  34:25    4  0 17  15:48    49:73  -24   46
21. Leicester City                42   7  5  9  20:23    6  1 14  20:44    40:67  -27   45
22. Crystal Palace                42   6  4 11  32:37    0  3 18  15:46    47:83  -36   25
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. West Ham United               42  19  1  1  53:12    9  9  3  26:17    79:29  +50   94
 2. Notts County                  42  10  8  3  26:15    8  9  4  23:23    49:38  +11   71
 3. Swansea City                  42  12  5  4  39:19    6  9  6  25:25    64:44  +20   68
 4. Luton Town                    42  10  6  5  35:23    8  6  7  26:23    61:46  +15   66
 5. Blackburn Rovers              42  12  8  1  28:7     4 10  7  14:22    42:29  +13   66
 6. Derby County                  42   9  8  4  34:26    6  7  8  23:26    57:52   +5   60
 7. Watford                       42  13  5  3  34:18    3  6 12  16:27    50:45   +5   59
 8. Sheffield Wednesday           42  14  4  3  38:14    3  4 14  15:37    53:51   +2   59
 9. Grimsby Town                  42  10  8  3  21:10    5  6 10  22:32    43:42   +1   59
10. Queens Park Rangers           42  11  7  3  36:12    4  6 11  20:34    56:46  +10   58
11. Cambridge United              42  13  1  7  36:23    4  5 12  17:42    53:65  -12   57
12. Newcastle United              42  11  7  3  22:13    3  7 11   8:32    30:45  -15   56
13. Chelsea                       42   8  6  7  27:15    6  6  9  19:26    46:41   +5   54
14. Shrewsbury Town               42  10  6  5  33:21    2 10  9  13:25    46:46        52
15. Bolton Wanderers              42  10  5  6  40:27    4  5 12  21:39    61:66   -5   52
16. Leyton Orient                 42   9  8  4  34:20    4  4 13  18:36    52:56   -4   51
17. Oldham Athletic               42   7  9  5  19:16    5  6 10  20:32    39:48   -9   51
18. Wrexham                       42   5  8  8  22:24    7  6  8  21:21    43:45   -2   50
19. Cardiff City                  42   7  7  7  23:24    5  5 11  21:36    44:60  -16   48
20. Preston North End             42   8  7  6  28:26    3  7 11  13:36    41:62  -21   47
21. Bristol City                  42   6 10  5  19:15    1  6 14  10:36    29:51  -22   37
22. Bristol Rovers                42   4  9  8  21:24    1  4 16  13:41    34:65  -31   28
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Rotherham United              46  17  6  0  43:8     7  7  9  19:24    62:32  +30   85
 2. Charlton Athletic             46  14  6  3  36:17   11  3  9  27:27    63:44  +19   84
 3. Barnsley                      46  15  5  3  46:19    6 12  5  26:26    72:45  +27   80
 4. Chesterfield                  46  17  4  2  42:16    6  6 11  30:32    72:48  +24   79
 5. Portsmouth                    46  14  5  4  35:19    8  4 11  20:28    55:47   +8   75
 6. Huddersfield Town             46  13  6  4  37:14    7  8  8  31:29    68:43  +25   74
 7. Plymouth Argyle               46  14  5  4  35:18    5  9  9  21:26    56:44  +12   71
 8. Burnley                       46  13  5  5  37:21    5  9  9  23:27    60:48  +12   68
 9. Reading                       46  13  5  5  39:22    5  5 13  23:40    62:62        64
10. Newport County                46  11  6  6  38:22    5  7 11  29:36    67:58   +9   61
11. Brentford                     46   7  9  7  30:25    7 10  6  22:24    52:49   +3   61
12. Exeter City                   46   9  9  5  36:30    7  4 12  26:36    62:66   -4   61
13. Fulham                        46   8  7  8  28:29    7  6 10  29:35    57:64   -7   58
14. Oxford United                 46   7  8  8  20:24    6  9  8  19:23    39:47   -8   56
15. Chester                       46  11  5  7  25:17    4  6 13  13:31    38:48  -10   56
16. Millwall                      46  10  9  4  30:21    4  5 14  13:39    43:60  -17   56
17. Carlisle United               46   8  9  6  32:29    6  4 13  24:41    56:70  -14   55
18. Sheffield United              46  12  6  5  38:20    2  6 15  27:43    65:63   +2   54
19. Swindon Town                  46  10  6  7  35:27    3  9 11  16:29    51:56   -5   54
20. Gillingham                    46   9  8  6  23:19    3 10 10  25:39    48:58  -10   54
21. Walsall                       46   8  9  6  43:43    5  6 12  16:31    59:74  -15   54
22. Colchester United             46  12  7  4  35:22    2  4 17  10:43    45:65  -20   53
23. Blackpool                     46   5  9  9  19:28    4  5 14  26:47    45:75  -30   41
24. Hull City                     46   7  8  8  23:22    1  8 14  17:49    40:71  -31   40
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Southend United               46  19  4  0  47:6    11  3  9  32:25    79:31  +48   97
 2. Lincoln City                  46  15  7  1  44:11   10  8  5  22:14    66:25  +41   90
 3. Wimbledon                     46  15  4  4  42:17    8  5 10  22:29    64:46  +18   78
 4. Doncaster Rovers              46  15  4  4  34:19    7  8  8  23:29    57:48   +9   78
 5. Peterborough United           46  11  8  4  37:21    6 10  7  31:33    68:54  +14   69
 6. Mansfield Town                46  13  5  5  36:15    7  4 12  22:29    58:44  +14   69
 7. Hartlepool United             46  14  3  6  42:22    6  6 11  22:39    64:61   +3   69
 8. Darlington                    46  13  6  4  43:23    6  5 12  22:36    65:59   +6   68
 9. Northampton Town              46  11  7  5  42:26    7  6 10  23:41    65:67   -2   67
10. Aldershot                     46  12  9  2  28:11    5  5 13  12:30    40:41   -1   65
11. Wigan Athletic                46  13  4  6  29:16    5  7 11  22:39    51:55   -4   65
12. Bury                          46  10  8  5  38:21    7  3 13  32:41    70:62   +8   62
13. AFC Bournemouth               46   9  8  6  30:21    7  5 11  17:27    47:48   -1   61
14. Rochdale                      46  12  6  5  35:23    3  9 11  27:45    62:68   -6   60
15. Torquay United                46  13  2  8  38:26    5  3 15  17:37    55:63   -8   59
16. Bradford City                 46   9  9  5  30:24    5  7 11  23:36    53:60   -7   58
17. Stockport County              46  10  5  8  29:25    6  2 15  15:32    44:57  -13   55
18. Scunthorpe United             46   8 12  3  40:31    3  8 12  20:38    60:69   -9   53
19. Crewe Alexandra               46  10  7  6  28:20    3  7 13  20:41    48:61  -13   53
20. Port Vale                     46  10  8  5  40:23    2  7 14  17:47    57:70  -13   51
21. Tranmere Rovers               46  12  5  6  41:24    1  5 17  18:49    59:73  -14   49
22. Hereford United               46   8  8  7  29:20    3  5 15   9:42    38:62  -24   46
23. York City                     46  10  2 11  31:23    2  7 14  16:43    47:66  -19   45
24. Halifax Town                  46   9  3 11  28:32    2  9 12  16:39    44:71  -27   45
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

