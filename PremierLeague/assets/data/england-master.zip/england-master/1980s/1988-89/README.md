

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       38  10  6  3  35:19   12  4  3  38:17    73:36  +37   76
 2. Liverpool                     38  11  5  3  33:11   11  5  3  32:17    65:28  +37   76
 3. Nottingham Forest             38   8  7  4  31:16    9  6  4  33:27    64:43  +21   64
 4. Norwich City                  38   8  7  4  23:20    9  4  6  25:25    48:45   +3   62
 5. Derby County                  38   9  3  7  23:18    8  4  7  17:20    40:38   +2   58
 6. Tottenham Hotspur             38   8  6  5  31:24    7  6  6  29:22    60:46  +14   57
 7. Coventry City                 38   9  4  6  28:23    5  9  5  19:19    47:42   +5   55
 8. Everton                       38  10  7  2  33:18    4  5 10  17:27    50:45   +5   54
 9. Queens Park Rangers           38   9  5  5  23:16    5  6  8  20:21    43:37   +6   53
10. Millwall                      38  10  3  6  27:21    4  8  7  20:31    47:52   -5   53
11. Manchester United             38  10  5  4  27:13    3  7  9  18:22    45:35  +10   51
12. Wimbledon                     38  10  3  6  30:19    4  6  9  20:27    50:46   +4   51
13. Southampton                   38   6  7  6  25:26    4  8  7  27:40    52:66  -14   45
14. Charlton Athletic             38   6  7  6  25:24    4  5 10  19:34    44:58  -14   42
15. Sheffield Wednesday           38   6  6  7  21:25    4  6  9  13:26    34:51  -17   42
16. Luton Town                    38   8  6  5  32:21    2  5 12  10:31    42:52  -10   41
17. Aston Villa                   38   7  6  6  25:22    2  7 10  20:34    45:56  -11   40
18. Middlesbrough                 38   6  7  6  28:30    3  5 11  16:31    44:61  -17   39
19. West Ham United               38   3  6 10  19:30    7  2 10  18:32    37:62  -25   38
20. Newcastle United              38   3  6 10  19:28    4  4 11  13:35    32:63  -31   31
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chelsea                       46  15  6  2  50:25   14  6  3  46:25    96:50  +46   99
 2. Manchester City               46  12  8  3  48:28   11  5  7  29:25    77:53  +24   82
 3. Crystal Palace                46  15  6  2  42:17    8  6  9  29:32    71:49  +22   81
 4. Watford                       46  14  5  4  41:18    8  7  8  33:30    74:48  +26   78
 5. Blackburn Rovers              46  16  4  3  50:22    6  7 10  24:37    74:59  +15   77
 6. Swindon Town                  46  13  8  2  35:15    7  8  8  33:38    68:53  +15   76
 7. Barnsley                      46  12  8  3  37:21    8  6  9  29:37    66:58   +8   74
 8. Ipswich Town                  46  13  3  7  42:23    9  4 10  29:38    71:61  +10   73
 9. West Bromwich Albion          46  13  7  3  43:18    5 11  7  22:23    65:41  +24   72
10. Leeds United                  46  12  6  5  34:20    5 10  8  25:30    59:50   +9   67
11. Sunderland                    46  12  8  3  40:23    4  7 12  20:37    60:60        63
12. AFC Bournemouth               46  13  3  7  32:20    5  5 13  21:42    53:62   -9   62
13. Stoke City                    46  10  9  4  33:25    5  5 13  24:47    57:72  -15   59
14. Bradford City                 46   8 11  4  29:22    5  6 12  23:37    52:59   -7   56
15. Leicester City                46  11  6  6  31:20    2 10 11  25:43    56:63   -7   55
16. Oldham Athletic               46   9 10  4  49:32    2 11 10  26:40    75:72   +3   54
17. Oxford United                 46  11  6  6  40:34    3  6 14  22:36    62:70   -8   54
18. Plymouth Argyle               46  11  4  8  35:22    3  8 12  20:44    55:66  -11   54
19. Brighton & Hove Albion        46  11  5  7  36:24    3  4 16  21:42    57:66   -9   51
20. Portsmouth                    46  10  6  7  33:21    3  6 14  20:41    53:62   -9   51
21. Hull City                     46   7  9  7  31:25    4  5 14  21:43    52:68  -16   47
22. Shrewsbury Town               46   4 11  8  25:31    4  7 12  15:36    40:67  -27   42
23. Birmingham City               46   6  4 13  21:33    2  7 14  10:43    31:76  -45   35
24. Walsall                       46   3 10 10  27:42    2  6 15  14:38    41:80  -39   31
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wolverhampton Wanderers       46  18  4  1  61:19    8 10  5  35:30    96:49  +47   92
 2. Sheffield United              46  16  3  4  57:21    9  6  8  36:33    93:54  +39   84
 3. Port Vale                     46  15  3  5  46:21    9  9  5  32:27    78:48  +30   84
 4. Fulham                        46  12  7  4  42:28   10  2 11  27:39    69:67   +2   75
 5. Bristol Rovers                46   9 11  3  34:21   10  6  7  33:30    67:51  +16   74
 6. Preston North End             46  14  7  2  56:31    5  8 10  23:29    79:60  +19   72
 7. Brentford                     46  14  5  4  36:21    4  9 10  30:40    66:61   +5   68
 8. Chester                       46  12  6  5  38:18    7  5 11  26:43    64:61   +3   68
 9. Notts County                  46  11  7  5  37:22    7  6 10  27:32    64:54  +10   67
10. Bolton Wanderers              46  12  8  3  42:23    4  8 11  16:31    58:54   +4   64
11. Bristol City                  46  10  3 10  32:25    8  6  9  21:30    53:55   -2   63
12. Swansea City                  46  11  8  4  33:22    4  8 11  18:31    51:53   -2   61
13. Bury                          46  11  7  5  27:22    5  6 12  28:45    55:67  -12   61
14. Huddersfield Town             46  10  8  5  35:25    7  1 15  28:48    63:73  -10   60
15. Mansfield Town                46  10  8  5  32:22    4  9 10  16:30    48:52   -4   59
16. Cardiff City                  46  10  9  4  30:16    4  6 13  14:40    44:56  -12   57
17. Wigan Athletic                46   9  5  9  28:22    5  9  9  27:31    55:53   +2   56
18. Reading                       46  10  6  7  37:29    5  5 13  31:43    68:72   -4   56
19. Blackpool                     46  10  6  7  36:29    4  7 12  20:30    56:59   -3   55
20. Northampton Town              46  11  2 10  41:34    5  4 14  25:42    66:76  -10   54
21. Southend United               46  10  9  4  33:26    3  6 14  23:49    56:75  -19   54
22. Chesterfield                  46   9  5  9  35:35    5  2 16  16:51    51:86  -35   49
23. Gillingham                    46   7  3 13  25:32    5  1 17  22:49    47:81  -34   40
24. Aldershot                     46   7  6 10  29:29    1  7 15  19:49    48:78  -30   37
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Rotherham United              46  13  6  4  44:18    9 10  4  32:17    76:35  +41   82
 2. Tranmere Rovers               46  15  6  2  34:13    6 11  6  28:30    62:43  +19   80
 3. Crewe Alexandra               46  13  7  3  42:24    8  8  7  25:24    67:48  +19   78
 4. Scunthorpe United             46  11  9  3  40:22   10  5  8  37:35    77:57  +20   77
 5. Scarborough                   46  12  7  4  33:23    9  7  7  34:29    67:52  +15   77
 6. Leyton Orient                 46  16  2  5  61:19    5 10  8  25:31    86:50  +36   75
 7. Wrexham                       46  12  7  4  44:28    7  7  9  33:35    77:63  +14   71
 8. Cambridge United              46  13  7  3  45:25    5  7 11  26:37    71:62   +9   68
 9. Grimsby Town                  46  11  9  3  33:18    6  6 11  32:41    65:59   +6   66
10. Lincoln City                  46  12  6  5  39:26    6  4 13  25:34    64:60   +4   64
11. York City                     46  10  8  5  43:27    7  5 11  19:36    62:63   -1   64
12. Carlisle United               46   9  6  8  26:25    6  9  8  27:27    53:52   +1   60
13. Exeter City                   46  14  4  5  46:23    4  2 17  19:45    65:68   -3   60
14. Torquay United                46  15  2  6  32:23    2  6 15  13:37    45:60  -15   59
15. Hereford United               46  11  8  4  40:27    3  8 12  26:45    66:72   -6   58
16. Burnley                       46  12  6  5  35:20    2  7 14  17:41    52:61   -9   55
17. Peterborough United           46  10  3 10  29:32    4  9 10  23:42    52:74  -22   54
18. Rochdale                      46  10 10  3  32:26    3  4 16  24:56    56:82  -26   53
19. Hartlepool United             46  10  6  7  33:33    4  4 15  17:45    50:78  -28   52
20. Stockport County              46   8 10  5  31:20    2 11 10  23:32    54:52   +2   51
21. Halifax Town                  46  10  7  6  42:27    3  4 16  27:48    69:75   -6   50
22. Colchester United             46   8  7  8  35:30    4  7 12  25:48    60:78  -18   50
23. Doncaster Rovers              46   9  6  8  32:32    4  4 15  17:46    49:78  -29   49
24. Darlington                    46   3 12  8  28:38    5  6 12  25:38    53:76  -23   42
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

