

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leeds United                  42  13  8  0  38:13    9  8  4  36:24    74:37  +37   82
 2. Manchester United             42  12  7  2  34:13    9  8  4  29:20    63:33  +30   78
 3. Sheffield Wednesday           42  13  5  3  39:24    8  7  6  23:25    62:49  +13   75
 4. Arsenal                       42  12  7  2  51:22    7  8  6  30:24    81:46  +35   72
 5. Manchester City               42  13  4  4  32:14    7  6  8  29:34    61:48  +13   70
 6. Liverpool                     42  13  5  3  34:17    3 11  7  13:23    47:40   +7   64
 7. Aston Villa                   42  13  3  5  31:16    4  6 11  17:28    48:44   +4   60
 8. Nottingham Forest             42  10  7  4  36:27    6  4 11  24:31    60:58   +2   59
 9. Sheffield United              42   9  6  6  29:23    7  3 11  36:40    65:63   +2   57
10. Crystal Palace                42   7  8  6  24:25    7  7  7  29:36    53:61   -8   57
11. Queens Park Rangers           42   6 10  5  25:21    6  8  7  23:26    48:47   +1   54
12. Everton                       42   8  8  5  28:19    5  6 10  24:32    52:51   +1   53
13. Wimbledon                     42  10  5  6  32:20    3  9  9  21:33    53:53        53
14. Chelsea                       42   7  8  6  31:30    6  6  9  19:30    50:60  -10   53
15. Tottenham Hotspur             42   7  3 11  33:35    8  4  9  25:28    58:63   -5   52
16. Southampton                   42   7  5  9  17:28    7  5  9  22:27    39:55  -16   52
17. Oldham Athletic               42  11  5  5  46:36    3  4 14  17:31    63:67   -4   51
18. Norwich City                  42   8  6  7  29:28    3  6 12  18:35    47:63  -16   45
19. Coventry City                 42   6  7  8  18:15    5  4 12  17:29    35:44   -9   44
20. Luton Town                    42  10  7  4  25:17    0  5 16  13:54    38:71  -33   42
21. Notts County                  42   7  5  9  24:29    3  5 13  16:33    40:62  -22   40
22. West Ham United               42   6  6  9  22:24    3  5 13  15:35    37:59  -22   38
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Ipswich Town                  46  16  3  4  42:22    8  9  6  28:28    70:50  +20   84
 2. Middlesbrough                 46  15  6  2  37:13    8  5 10  21:28    58:41  +17   80
 3. Derby County                  46  11  4  8  35:24   12  5  6  34:27    69:51  +18   78
 4. Leicester City                46  14  4  5  41:24    9  4 10  21:31    62:55   +7   77
 5. Cambridge United              46  10  9  4  34:19    9  8  6  31:28    65:47  +18   74
 6. Blackburn Rovers              46  14  5  4  41:21    7  6 10  29:32    70:53  +17   74
 7. Charlton Athletic             46   9  7  7  25:23   11  4  8  29:25    54:48   +6   71
 8. Swindon Town                  46  15  3  5  38:22    3 12  8  31:33    69:55  +14   69
 9. Portsmouth                    46  15  6  2  41:12    4  6 13  24:39    65:51  +14   69
10. Watford                       46   9  5  9  25:23    9  6  8  26:25    51:48   +3   65
11. Wolverhampton Wanderers       46  11  6  6  36:24    7  4 12  25:30    61:54   +7   64
12. Southend United               46  11  5  7  37:26    6  6 11  26:37    63:63        62
13. Bristol Rovers                46  11  9  3  43:29    5  5 13  17:34    60:63   -3   62
14. Tranmere Rovers               46   9  9  5  37:32    5 10  8  19:24    56:56        61
15. Millwall                      46  10  4  9  32:32    7  6 10  32:39    64:71   -7   61
16. Barnsley                      46  11  4  8  27:25    5  7 11  19:32    46:57  -11   59
17. Bristol City                  46  10  8  5  30:24    3  7 13  25:47    55:71  -16   54
18. Sunderland                    46  10  8  5  36:23    4  3 16  25:42    61:65   -4   53
19. Grimsby Town                  46   7  5 11  25:28    7  6 10  22:34    47:62  -15   53
20. Newcastle United              46   9  8  6  38:30    4  5 14  28:54    66:84  -18   52
21. Oxford United                 46  10  6  7  39:30    3  5 15  27:43    66:73   -7   50
22. Plymouth Argyle               46  11  5  7  26:26    2  4 17  16:38    42:64  -22   48
23. Brighton & Hove Albion        46   7  7  9  36:37    5  4 14  20:40    56:77  -21   47
24. Port Vale                     46   7  8  8  23:25    3  7 13  19:34    42:59  -17   45
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Brentford                     46  17  2  4  55:29    8  5 10  26:26    81:55  +26   82
 2. Birmingham City               46  15  6  2  42:22    8  6  9  27:30    69:52  +17   81
 3. Huddersfield Town             46  15  4  4  36:15    7  8  8  23:23    59:38  +21   78
 4. Stoke City                    46  14  5  4  45:24    7  9  7  24:25    69:49  +20   77
 5. Stockport County              46  15  5  3  47:19    7  5 11  28:32    75:51  +24   76
 6. Peterborough United           46  13  7  3  38:20    7  7  9  27:38    65:58   +7   74
 7. West Bromwich Albion          46  12  6  5  45:25    7  8  8  19:24    64:49  +15   71
 8. AFC Bournemouth               46  13  4  6  33:18    7  7  9  19:30    52:48   +4   71
 9. Fulham                        46  11  7  5  29:16    8  6  9  28:37    57:53   +4   70
10. Leyton Orient                 46  12  7  4  36:18    6  4 13  26:34    62:52  +10   65
11. Hartlepool United             46  12  5  6  30:21    6  6 11  27:36    57:57        65
12. Reading                       46   9  8  6  33:27    7  5 11  26:35    59:62   -3   61
13. Bolton Wanderers              46  10  9  4  26:19    4  8 11  31:37    57:56   +1   59
14. Hull City                     46   9  4 10  28:23    7  7  9  26:31    54:54        59
15. Wigan Athletic                46  11  6  6  33:21    4  8 11  25:43    58:64   -6   59
16. Bradford City                 46   8 10  5  36:30    5  9  9  26:31    62:61   +1   58
17. Preston North End             46  12  7  4  42:32    3  5 15  19:40    61:72  -11   57
18. Chester                       46  10  6  7  34:29    4  8 11  22:30    56:59   -3   56
19. Swansea City                  46  10  9  4  35:24    4  5 14  20:41    55:65  -10   56
20. Exeter City                   46  11  7  5  34:25    3  4 16  23:55    57:80  -23   53
21. Bury                          46   8  7  8  31:31    5  5 13  24:43    55:74  -19   51
22. Shrewsbury Town               46   7  7  9  30:31    5  4 14  23:37    53:68  -15   47
23. Torquay United                46  13  3  7  29:19    0  5 18  13:49    42:68  -26   47
24. Darlington                    46   5  5 13  31:39    5  2 16  25:51    56:90  -34   37
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Burnley                       42  14  4  3  42:16   11  4  6  37:27    79:43  +36   83
 2. Rotherham United              42  12  6  3  38:16   10  5  6  32:21    70:37  +33   77
 3. Mansfield Town                42  13  4  4  43:26   10  4  7  32:27    75:53  +22   77
 4. Blackpool                     42  17  3  1  48:13    5  7  9  23:32    71:45  +26   76
 5. Scunthorpe United             42  14  5  2  39:18    7  4 10  25:41    64:59   +5   72
 6. Crewe Alexandra               42  12  6  3  33:20    8  4  9  33:31    66:51  +15   70
 7. Barnet                        42  16  1  4  48:23    5  5 11  33:38    81:61  +20   69
 8. Rochdale                      42  12  6  3  34:22    6  7  8  23:31    57:53   +4   67
 9. Cardiff City                  42  13  3  5  42:26    4 12  5  24:27    66:53  +13   66
10. Lincoln City                  42   9  5  7  21:24    8  6  7  29:20    50:44   +6   62
11. Gillingham                    42  12  5  4  41:19    3  7 11  22:34    63:53  +10   57
12. Scarborough                   42  12  5  4  39:28    3  7 11  25:40    64:68   -4   57
13. Chesterfield                  42   6  7  8  26:28    8  4  9  23:33    49:61  -12   53
14. Wrexham                       42  11  4  6  31:26    3  5 13  21:47    52:73  -21   51
15. Walsall                       42   5 10  6  28:26    7  3 11  20:32    48:58  -10   49
16. Northampton Town              42   5  9  7  25:23    6  4 11  21:34    46:57  -11   46
17. Hereford United               42   9  4  8  31:24    3  4 14  13:33    44:57  -13   44
18. Maidstone United              42   6  9  6  24:22    2  9 10  21:34    45:56  -11   42
19. York City                     42   6  9  6  26:23    2  7 12  16:35    42:58  -16   40
20. Halifax Town                  42   7  5  9  23:35    3  3 15  11:40    34:75  -41   38
21. Doncaster Rovers              42   6  2 13  21:35    3  6 12  19:30    40:65  -25   35
22. Carlisle United               42   5  9  7  24:27    2  4 15  17:40    41:67  -26   34
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

